extends Area2D

@export var tipo_objeto = "lista"

@onready var label_interacao: Label = $LabelInteracao
@onready var caixa_dialogo: Label = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo

var player_perto = false
var mostrando_dialogo = false
var ja_interagiu = false

func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

func _process(_delta):

	if player_perto and Input.is_action_just_pressed("investigate") and not mostrando_dialogo:
		interagir()

func interagir():

	match tipo_objeto:

		"lista":
			if not ja_interagiu:
				GameManager.pegar_objeto("lista")
				ja_interagiu = true
			mostrar_dialogo("Achei a lista que a mamãe pediu.")

		"fita":
			if not ja_interagiu:
				GameManager.pegar_objeto("fita")
				ja_interagiu = true
			mostrar_dialogo("Encontrei a fita adesiva.")

		"panela":
			if not ja_interagiu:
				GameManager.pegar_objeto("panela")
				ja_interagiu = true
			mostrar_dialogo("Aqui está a panela.")

		"foto":
			if not ja_interagiu:
				GameManager.pegar_objeto("foto_familia")
				ja_interagiu = true
			mostrar_dialogo("Essa foto foi tirada antes de... bem...")

		"caderno":
			if not ja_interagiu:
				GameManager.pegar_objeto("caderno")
				ja_interagiu = true
			mostrar_dialogo("Talvez eu desenhe um pouco depois.")

		"caixa_pai":
			if not ja_interagiu:
				GameManager.pegar_objeto("caixa_pai")
				GameManager.pegar_objeto("relogio")
				GameManager.pegar_objeto("ferramentas")
				GameManager.pegar_objeto("foto_pai")
				ja_interagiu = true

			mostrar_dialogo("Essas coisas... eram do pai.\nO relógio dele... as ferramentas também.\nEu achei que a mamãe tivesse jogado tudo isso fora.")

		"chave":
			if not ja_interagiu:
				GameManager.pegar_objeto("chave")
				ja_interagiu = true
			mostrar_dialogo("Uma chave... talvez abra aquela porta.")

func mostrar_dialogo(msg):

	mostrando_dialogo = true

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = msg

	await get_tree().create_timer(3.0).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	mostrando_dialogo = false

func _on_body_entered(body):
	if body.name == "Lina":
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione I para investigar"

func _on_body_exited(body):
	if body.name == "Lina":
		player_perto = false
		label_interacao.visible = false
		caixa_dialogo.visible = false
		texto_dialogo.visible = false
		mostrando_dialogo = false
