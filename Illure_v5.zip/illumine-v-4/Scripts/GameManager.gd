extends Node

# ==================================================
# GAME MANAGER - ILLURE
# AutoLoad: GameManager
# ==================================================

# ETAPAS
# 0 = início / falar com a mãe
# 1 = procurar objetos da casa
# 2 = encontrou tudo / voltar pra mãe
# 3 = briga / porta aparece
# 4 = procurar chave
# 5 = porta aberta / túnel

var etapa = 0

# ==================================================
# ITENS PRINCIPAIS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

# ==================================================
# EXPLORAÇÃO
# ==================================================
var foto_familia = false
var caderno_lina = false
var caixa_pai = false

# ==================================================
# PORTA
# ==================================================
var chave_porta = false

# ==================================================
# RESETAR JOGO
# ==================================================
func novo_jogo():

	etapa = 0

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false

	chave_porta = false

# ==================================================
# FALOU COM A MÃE
# ==================================================
func falou_com_mae_inicio():

	if etapa == 0:
		etapa = 1

# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista":
			item_lista = true

		"fita":
			item_fita = true

		"panela":
			item_panela = true

		"foto_familia":
			foto_familia = true

		"caderno":
			caderno_lina = true

		"caixa_pai":
			caixa_pai = true

		"chave":
			chave_porta = true

	verificar_progresso()

# ==================================================
# VERIFICAR PROGRESSO
# ==================================================
func verificar_progresso():

	# ETAPA 1 -> ETAPA 2
	if etapa == 1:
		if item_lista and item_fita and item_panela:
			if foto_familia and caderno_lina and caixa_pai:
				etapa = 2

	# ETAPA 4 -> ETAPA 5
	if etapa == 4:
		if chave_porta:
			etapa = 5

# ==================================================
# ENTREGOU ITENS PRA MÃE
# ==================================================
func entregou_objetos_mae():

	if etapa == 2:
		etapa = 3

# ==================================================
# LIBERAR BUSCA DA CHAVE
# ==================================================
func iniciar_busca_chave():

	if etapa == 3:
		etapa = 4
