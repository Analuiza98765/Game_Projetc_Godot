extends Area2D

# =====================================
# UI
# =====================================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =====================================
# ESTADO
# =====================================
var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0

var falas = [
	"Você foi longe demais...",
	"Eu não queria isso...",
	"Já não consegue voltar agora.",
	"Então me ajuda!",
	"Esse mundo mudou você.",
	"Eu só quero sair daqui...",
	"Eu tentei avisar...",
	"Os meus pais estão vindo!",
	"Me desculpa, Lina."
]


func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
	label_interacao.visible = false

	# só aparece na etapa 14
	visible = GameManager.etapa >= 15


func _process(_delta):

	if GameManager.etapa != 15:
		return

	# iniciar diálogo
	if player_perto \
	and not falando \
	and not GameManager.em_dialogo \
	and Input.is_action_just_pressed("interact"):

		iniciar_dialogo()

	# avançar fala
	elif falando \
	and pode_avancar \
	and Input.is_action_just_pressed("interact"):

		proxima_fala()


# =====================================
# INICIAR
# =====================================
func iniciar_dialogo():

	falando = true

	GameManager.iniciar_dialogo()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0

	proxima_fala()


# =====================================
# PRÓXIMA FALA
# =====================================
func proxima_fala():

	if fala_index >= falas.size():

		finalizar_dialogo()
		return

	pode_avancar = false

	texto_dialogo.text = ""

	var texto = falas[fala_index]

	fala_index += 1

	await mostrar_texto(texto)


# =====================================
# TEXTO ANIMADO
# =====================================
func mostrar_texto(msg):

	for letra in msg:

		texto_dialogo.text += letra

		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


# =====================================
# FINAL
# =====================================
func finalizar_dialogo():

	encerrar_dialogo()

	# etapa 15
	GameManager.falou_com_gato_final = true

	GameManager.verificar_progresso()


func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	caixa_dialogo.visible = false
	texto_dialogo.visible = false


# =====================================
# DETECÇÃO
# =====================================
func _on_body_entered(body):

	if body.is_in_group("player") \
	and GameManager.etapa == 15:

		player_perto = true

		label_interacao.visible = true
		label_interacao.text = "Pressione E para conversar"


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false

		label_interacao.visible = false

		if falando:
			encerrar_dialogo()
