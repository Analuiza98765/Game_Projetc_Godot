extends CharacterBody2D

@export var speed = 130
@export var distancia_minima = 14
@export var offset_atras = Vector2(-20, 12)

var player: CharacterBody2D = null

# =====================================
# CONTROLE
# =====================================
var parado_dialogo = false
var player_perto = false   # 🔥 NOVO (AREA DETECT)

# =====================================
# READY
# =====================================
func _ready():

	player = get_tree().get_first_node_in_group("player")

	_atualizar_estado_por_etapa(GameManager.etapa)

	if GameManager.has_signal("etapa_mudou"):
		GameManager.etapa_mudou.connect(_on_etapa_mudou)

	# 🔥 conecta Area2D (NOME DO NODE PRECISA SER "Area2D")
	$Area2D.body_entered.connect(_on_body_entered)
	$Area2D.body_exited.connect(_on_body_exited)


# =====================================
# DETECÇÃO
# =====================================
func _on_body_entered(body):

	if body.is_in_group("player"):
		player_perto = true


func _on_body_exited(body):

	if body.is_in_group("player"):
		player_perto = false


# =====================================
# ETAPA
# =====================================
func _on_etapa_mudou(nova_etapa: int) -> void:
	_atualizar_estado_por_etapa(nova_etapa)


func _atualizar_estado_por_etapa(etapa_atual: int) -> void:
	visible = etapa_atual >= 10


# =====================================
# MOVIMENTO
# =====================================
func _physics_process(delta):

	if GameManager.etapa < 10:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	if player == null:
		return


	# =====================================
	# PARA SE ESTIVER PERTO DO PLAYER
	# =====================================
	if player_perto:
		velocity = Vector2.ZERO
		move_and_slide()
		return


	# =====================================
	# ETAPA 10 = PARADO
	# =====================================
	if GameManager.etapa == 10:
		velocity = Vector2.ZERO
		move_and_slide()
		return


	# =====================================
	# DIÁLOGO GLOBAL
	# =====================================
	if GameManager.em_dialogo or parado_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return


	# =====================================
	# SEGUE O PLAYER
	# =====================================
	var alvo = player.global_position + offset_atras
	var direcao = alvo - global_position
	var distancia = direcao.length()

	if player.velocity.length() > 0:

		if distancia > distancia_minima:
			velocity = velocity.lerp(
				direcao.normalized() * speed,
				0.2
			)
		else:
			velocity = Vector2.ZERO

	else:
		velocity = Vector2.ZERO

	move_and_slide()
