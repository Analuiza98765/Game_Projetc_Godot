extends Node

signal objetivo_concluido
signal etapa_mudou(nova_etapa)

@onready var door_secret = get_node("../door_secret")
@onready var mae = get_node("../Mae")
@onready var pai = get_node("../Pai")
@onready var area_dialogo_pai = get_tree().get_first_node_in_group("dialogo_pai")

var objetivos

func _ready():

	await get_tree().process_frame

	objetivos = get_tree().get_first_node_in_group("objetivos")

	print(objetivos)
# ==================================================
# CONTROLE GLOBAL
# ==================================================
var etapa = 0
var em_dialogo = false
var cena_atual = ""
var encontrou_porta = false
var abriu_porta = false
var porta_outro_mundo = false
var falar_outra_mae = false
var falar_outro_pai = false
var encontrou_gato = false
var encontrou_porta_secreta = false
var pais_perseguem = false
var falou_com_gato_final = false
var pais_apareceram = false
var em_cutscene = false
var irmao_jogando_pedra = false
var dialogo_terminou = false
var player_pode_andar = false

# referências



func avancar_etapa(nova_etapa):

	if nova_etapa > etapa:

		etapa = nova_etapa

		print("ETAPA ATUAL:", etapa)

		emit_signal("etapa_mudou", etapa)
		
		verificar_progresso()
		

# ==================================================
# CONTROLE DE DIÁLOGO
# ==================================================
func iniciar_dialogo():
	em_dialogo = true

func encerrar_dialogo():
	em_dialogo = false

# ==================================================
# ITENS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

var foto_familia = false
var caderno_lina = false
var caixa_pai = false
var chave_porta = false
var foto_outra_familia = false
var caderno_outra_lina = false
var caixa_outro_pai = false
var quadro_sombrio = false
var urso_empalhado_sangrando = false
var olho_na_parede = false
var espelho_estranho = false

var boneca_quebrada = false
var ursinho_rasgado = false
var bilhetes_socorro = false
var sangue_chao = false
var objetos_tortura = false
var mesa_jantar = false

var confronto_pai = false
var confronto_mae = false
var esperar_porta_mae = false
var esperar_porta_pai = false
var pai_chegou_porta = false
var mae_chegou_porta = false

var falar_mae_etapa3 = false
# ==================================================
# RESET
# ==================================================
func novo_jogo():

	etapa = 0
	em_dialogo = false

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false
	chave_porta = false
	foto_outra_familia = false
	caderno_outra_lina = false
	caixa_outro_pai = false
	
	print("JOGO RESETADO")

# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista":
			item_lista = true

		"fita":
			item_fita = true

		"panela":
			item_panela = true

		"foto":
			foto_familia = true

		"caderno":
			caderno_lina = true

		"caixa_pai":
			caixa_pai = true

		"chave":
			chave_porta = true

			print("Pegou a chave")
		
		"foto_outro":
			foto_outra_familia = true
		
		"caderno_outro":
			caderno_outra_lina = true
		
		"caixa_outro":
			caixa_outro_pai = true

		"quadro_sombrio":
			quadro_sombrio = true

		"olho_na_parede":
			olho_na_parede = true

		"urso_empalhado_sangrando":
			urso_empalhado_sangrando = true

		"espelho_estranho":
			espelho_estranho = true	
		
		"boneca_quebrada": 
			boneca_quebrada = true
			
		"ursinho_rasgado": 
			ursinho_rasgado = true
			
		"bilhetes_socorro": 
			bilhetes_socorro = true
		
		"sangue_chao": 
			sangue_chao = true
			
		"objetos_tortura": 
			objetos_tortura = true
		
		"mesa_jantar": 
			mesa_jantar = true
		
func iniciar_cutscene_porta_final():

	em_cutscene = true

	player_pode_andar = false

	dialogo_terminou = false

	# inicia diálogo automático
	area_dialogo_pai.iniciar_dialogo()

	while not dialogo_terminou:
		await get_tree().process_frame

	irmao_jogando_pedra = true

	pais_perseguem = true

	player_pode_andar = true

	em_cutscene = false

	esperar_porta_mae = false
	esperar_porta_pai = false

	pai_chegou_porta = false
	mae_chegou_porta = false

	avancar_etapa(15)

func verificar_progresso():

	if etapa == 0:
		avancar_etapa(1)

	elif etapa == 1:
		print("esta na etapa 1")
		if item_fita and item_panela and foto_familia and caderno_lina:

			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(2)

	elif etapa == 2:

		print("esta na etapa 2")

		if objetivos == null:
			print("null")
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			print("não null")
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com mãe"

		if caixa_pai:
			print("caixa pai n null")
			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(3)

	elif etapa == 3:
		print("esta na etapa 3")
		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.show()
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com mãe"
			
		if falar_mae_etapa3:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Encontrar Porta"

		if encontrou_porta:
			if objetivos:
				objetivos.get_node("Check").show()
				

			await get_tree().create_timer(1.0).timeout

			avancar_etapa(4)

	elif etapa == 4:
		print("esta na etapa 4")
		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Encontrar a chave"

		if chave_porta:
			objetivos.get_node("Check").show()

			avancar_etapa(5)
	
	elif etapa == 5:
		print("esta na etapa 5")
		if abriu_porta:
			avancar_etapa(6)
	
	elif etapa == 6:
		print("esta na etapa 6")
		if porta_outro_mundo:
			avancar_etapa(7)

	elif etapa == 7:
			print("esta na etapa 7")
			if objetivos == null:
				print("objetivo é null")
				objetivos = get_tree().get_first_node_in_group("objetivos")
			
			if objetivos:
				print("objetivo é true")
				objetivos.get_node("Label").text = "Explorar a casa"

			if foto_outra_familia and caderno_outra_lina and caixa_outro_pai:
				if objetivos:
					print("pegou os 3 objetos")
					objetivos.get_node("Check").show()

				avancar_etapa(8)
		
	elif etapa == 8:
		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com a outra mãe"

		if falar_outra_mae:
			objetivos.get_node("Check").show()

			avancar_etapa(9)


	elif etapa == 9:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com o outro pai"

		if falar_outro_pai:
			if objetivos:
				objetivos.get_node("Check").show()

			avancar_etapa(10)
	
	elif etapa == 10:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Falar com o gato"

		if encontrou_gato:
			avancar_etapa(11)
			
	elif etapa == 11:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Investigar os objetos estranhos"

		if quadro_sombrio \
		and olho_na_parede \
		and urso_empalhado_sangrando \
		and espelho_estranho:

			if objetivos:
				objetivos.get_node("Check").show()

				avancar_etapa(12)

	elif etapa == 12:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Investigar o porão"

		# CHECAGEM DOS OBJETOS (fora do bloco de UI, mais seguro)
		if boneca_quebrada \
		and ursinho_rasgado \
		and bilhetes_socorro \
		and sangue_chao \
		and objetos_tortura \
		and mesa_jantar:

			objetivos.get_node("Check").show()
			avancar_etapa(13)
						
	elif etapa == 13:
	# pais aparecem na porta
		if pais_apareceram:
			avancar_etapa(14)
			
			
	elif etapa == 14:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Escapar dos pais"

		# manda os pais irem até a porta
		esperar_porta_mae = true
		esperar_porta_pai = true

		# quando os dois chegam
		if pai_chegou_porta \
		and mae_chegou_porta \
		and not em_cutscene:

			iniciar_cutscene_porta_final()
		
	elif etapa == 15:

		if objetivos == null:
			objetivos = get_tree().get_first_node_in_group("objetivos")

		if objetivos:
			objetivos.get_node("Check").hide()
			objetivos.get_node("Label").text = "Pedir ajuda ao gato"

		if falou_com_gato_final:

			objetivos.get_node("Check").show()
			avancar_etapa(16)

	
	elif etapa == 16:
		avancar_etapa(17)
		get_tree().change_scene_to_file("res://Scenes/final_ruim.tscn")
			
func mostrar_objetivo_concluido():

	var aviso = get_tree().current_scene.get_node_or_null("CanvasLayer/AvisoObjetivo")

	if aviso == null:
		return

	aviso.text = "✔ Já peguei tudo\nA mamãe deve estar me esperando..."

	aviso.visible = true

	await get_tree().create_timer(3.0).timeout

	aviso.visible = false

func verificar_lista_completa():

	if item_fita and item_panela and foto_familia and caderno_lina:
		mostrar_objetivo_concluido()
		verificar_progresso()
		var lista = get_tree().current_scene.get_node_or_null("CanvasLayer/Lista")
		if lista:
			lista.hide()
