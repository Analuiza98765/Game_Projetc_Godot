extends Area2D

var player_perto = false

# UI GLOBAL
var ui
var label_interacao

func _ready() -> void:

	ui = get_tree().current_scene.get_node("CanvasLayer")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false


func _process(delta: float) -> void:

	if player_perto and Input.is_action_just_pressed("interact"):

		get_tree().change_scene_to_file("res://Scenes/porao.tscn")


func _on_body_entered(body):

	if body.is_in_group("player"):

		player_perto = true

		label_interacao.text = "Pressione E para entrar"
		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false

		label_interacao.visible = false
