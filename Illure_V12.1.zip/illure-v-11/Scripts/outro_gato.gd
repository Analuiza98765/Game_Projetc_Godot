extends CharacterBody2D

@onready var sprite = $AnimatedSprite2D

var player_perto = false
var ja_falou = false

var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

var falas = [
	"Gato...",
	"Me ajuda... por favor... eu quero ir embora.",
	"...",
	"Desculpa.",
	"Você foi longe demais.",
	"Você atravessou uma linha sem volta.",
	"Quanto mais você procurava respostas...",
	"...mais esse mundo passou a te reconhecer como parte dele.",
	"Não existe mais caminho de volta pra casa.",
	"Desculpa.",
	"Não..."
]

var fala_index = 0
var escrevendo = false
var texto_completo = ""


func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")


func _physics_process(_delta):
	GameManager.etapa = 15
	visible = GameManager.etapa == 15

	if !visible:
		return

	if player_perto and Input.is_action_just_pressed("interact"):

		if !ja_falou and !GameManager.em_dialogo:
			iniciar_dialogo()
			return

		if GameManager.em_dialogo:

			if escrevendo:
				texto_dialogo.text = texto_completo
				escrevendo = false
			else:
				proxima_fala()


func iniciar_dialogo():

	ja_falou = true

	GameManager.iniciar_dialogo()

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	label_interacao.visible = false

	fala_index = 0

	proxima_fala()


func proxima_fala():
	
	if fala_index >= falas.size():

		if GameManager.etapa == 15:
			GameManager.falou_com_gato_final = true
			GameManager.verificar_progresso()

		finalizar_dialogo()
		return

	texto_completo = falas[fala_index]

	fala_index += 1

	await escrever_texto(texto_completo)


func escrever_texto(texto):

	escrevendo = true

	texto_dialogo.text = ""

	for letra in texto:

		if !escrevendo:
			return

		texto_dialogo.text += letra

		await get_tree().create_timer(0.03).timeout

	escrevendo = false


func finalizar_dialogo():

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	GameManager.encerrar_dialogo()
