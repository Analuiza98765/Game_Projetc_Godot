extends Area2D

# =============================
# UI GLOBAL
# =============================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =============================
# ESTADO
# =============================
var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []


# =============================
# READY
# =============================
func _ready():

	if get_tree().current_scene.has_node("CanvasLayer"):
		ui = get_tree().current_scene.get_node("CanvasLayer")
	else:
		return
	if ui == null:
		return

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


# =============================
# LOOP
# =============================
func _process(_delta):
	
	if GameManager.etapa >= 16:

		label_interacao.visible = false
		player_perto = false

		if falando:
			encerrar_dialogo()

		return

	if player_perto \
	and not falando \
	and not GameManager.em_dialogo \
	and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando \
	and pode_avancar \
	and Input.is_action_just_pressed("interact"):
		proxima_fala()


# =============================
# FALAS
# =============================
func pegar_falas():

	match GameManager.etapa:
		8:
			return [
				"Finalmente você chegou!",
				"Cheguei?",
				"Estávamos esperando por você.",
				"‘Estávamos esperando’... mas… essa é a minha casa?",
				"É a sua casa mas melhor."
			]

		# ==================================================
		# DEPOIS
		# ==================================================
		9:
			return [
				"Seu pai está te procurando, por que não vai dar um oi pra ele?",
				"Tenho certeza de que ele vai adorar te ver."
			]

		10:
			return [
				"Você gostou daqui, não gostou?",
				"Aqui tudo pode ser perfeito."
			]

	return ["..."]


# =============================
# INICIAR
# =============================
func iniciar_dialogo():

	falando = true

	GameManager.iniciar_dialogo()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0
	falas = pegar_falas()

	proxima_fala()


# =============================
# AVANÇAR
func proxima_fala():

	if fala_index >= falas.size():

		# ✔ marca progresso só quando terminou TODAS as falas
		if GameManager.etapa == 8:
			GameManager.falar_outra_mae = true
			GameManager.verificar_progresso()

		encerrar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]
	fala_index += 1

	await mostrar_texto(texto)


# =============================
# TEXTO
# =============================
func mostrar_texto(msg):

	for letra in msg:

		texto_dialogo.text += letra

		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


# =============================
# FINAL
# =============================
func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	caixa_dialogo.visible = false
	texto_dialogo.visible = false



# =============================
# DETECÇÃO
# =============================
func _on_body_entered(body):
	if GameManager.etapa < 8:
		visible = false
		return

	if GameManager.etapa >= 12 and GameManager.etapa <= 13:
		visible = false
		return
	
	visible = true

	if body.is_in_group("player"):

		player_perto = true

		get_parent().npc_parado = true

		label_interacao.text = "Pressione E para conversar"
		label_interacao.visible = true

func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false

		get_parent().npc_parado = false

		label_interacao.visible = false

		if falando:
			encerrar_dialogo()
