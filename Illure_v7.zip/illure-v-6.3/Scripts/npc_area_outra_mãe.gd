extends Area2D

# =============================
# UI GLOBAL
# =============================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =============================
# ESTADO
# =============================
var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []


# =============================
# READY
# =============================
func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


# =============================
# LOOP
# =============================
func _process(_delta):

	if player_perto \
	and not falando \
	and not GameManager.em_dialogo \
	and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando \
	and pode_avancar \
	and Input.is_action_just_pressed("interact"):
		proxima_fala()


# =============================
# FALAS
# =============================
func pegar_falas():

	match GameManager.etapa:

		# ==================================================
		# PRIMEIRO ENCONTRO
		# ==================================================
		8:
			return [
				"Você finalmente chegou.",
				"Estávamos esperando por você.",
				"Esta casa é sua... só que melhor.",
				"Aqui ninguém vai te ignorar.",
				"Por que não vai falar com seu pai também?"
			]

		# ==================================================
		# DEPOIS
		# ==================================================
		9:
			return [
				"Seu pai está esperando por você.",
				"Tenho certeza de que ele vai adorar te ver."
			]

		10:
			return [
				"Você gostou daqui, não gostou?",
				"Aqui tudo pode ser perfeito."
			]

	return ["..."]


# =============================
# INICIAR
# =============================
func iniciar_dialogo():

	falando = true

	GameManager.iniciar_dialogo()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0
	falas = pegar_falas()

	proxima_fala()


# =============================
# AVANÇAR
# =============================
func proxima_fala():

	if fala_index >= falas.size():

		encerrar_dialogo()

		return

	pode_avancar = false

	texto_dialogo.text = ""

	var texto = falas[fala_index]

	fala_index += 1

	await mostrar_texto(texto)


# =============================
# TEXTO
# =============================
func mostrar_texto(msg):

	for letra in msg:

		texto_dialogo.text += letra

		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


# =============================
# FINAL
# =============================
func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
	GameManager.falar_outra_mae = true
	GameManager.verificar_progresso()


# =============================
# DETECÇÃO
# =============================
func _on_body_entered(body):

	if body.is_in_group("player"):

		player_perto = true

		label_interacao.text = "Pressione E para conversar"

		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false

		label_interacao.visible = false

		if falando:

			encerrar_dialogo()
