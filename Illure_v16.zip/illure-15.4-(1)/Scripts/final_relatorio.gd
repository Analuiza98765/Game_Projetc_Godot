extends Control

func _ready():

	$ColorRect.visible = true

	for node in get_children():
		if node != $ColorRect:
			node.visible = false

	mostrar_relatorio()


func mostrar_relatorio():

	$Titulo.visible = true
	await get_tree().create_timer(0.5).timeout

	$Tempo.text = \
	"Tempo total: " + GameManager.formatar_tempo()

	$Tempo.visible = true
	await get_tree().create_timer(0.5).timeout


	$Objetos.text = \
	"Objetos encontrados: " + str(GameManager.objetos_encontrados)

	$Objetos.visible = true
	await get_tree().create_timer(0.5).timeout


	$Portas.text = \
	"Portas atravessadas: " + str(GameManager.portas_atravessadas)

	$Portas.visible = true
	await get_tree().create_timer(0.5).timeout


	$Distancia.text = \
	"Distância percorrida: " + GameManager.distancia_formatada()

	$Distancia.visible = true
	await get_tree().create_timer(0.5).timeout

	$Final.text = \
	"Final alcançado: " + GameManager.final_alcancado

	$Final.visible = true


func _on_voltar_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")
	pass # Replace with function body.
