extends Area2D

# =============================
# UI GLOBAL
# =============================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =============================
# ESTADO
# =============================
var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []

# =============================
# READY
# =============================
func _ready():

	await get_tree().process_frame

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


# =============================
# LOOP
# =============================
func _process(_delta):

	# =====================================
	# VISIBILIDADE DO GATO
	# =====================================
	if GameManager.etapa < 10:

		visible = false
		monitoring = false
		monitorable = false

		return


	# =====================================
	# SOME NA PERSEGUIÇÃO
	# =====================================
	if GameManager.etapa >= 14:

		visible = false
		monitoring = false
		monitorable = false

		player_perto = false

		label_interacao.visible = false

		if falando:
			encerrar_dialogo()

		return


	# =====================================
	# ATIVO
	# =====================================
	visible = true

	monitoring = true
	monitorable = true


	# =====================================
	# INICIAR DIÁLOGO
	# =====================================
	if player_perto \
	and not falando \
	and not GameManager.em_dialogo \
	and Input.is_action_just_pressed("interact"):

		iniciar_dialogo()


	# =====================================
	# AVANÇAR FALA
	# =====================================
	elif falando \
	and pode_avancar \
	and Input.is_action_just_pressed("interact"):

		proxima_fala()


# =============================
# FALAS
# =============================
func pegar_falas():

	match GameManager.etapa:

		10:
			return [
				"Que susto você me deu gatinho, já estava pensando que vo-",
				"Vocês não são daqui, crianças.",
				"O que…? Você fala???",
				"Não se confundam, nem tudo que vocês vêem é o que parece ser.",
				"…",
				"Talvez vocês devessem prestar mais atenção ao seu redor."
			]

		11:
			return [
				"Agora eu vou com você.",
				"Você vai precisar de ajuda.",
				"E rápido."
			]

	return ["..."]


# =============================
# INICIAR DIÁLOGO
# =============================
func iniciar_dialogo():

	if falando:
		return

	falando = true

	GameManager.iniciar_dialogo()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0
	falas = pegar_falas()

	proxima_fala()


# =============================
# PRÓXIMA FALA
# =============================
func proxima_fala():

	if fala_index >= falas.size():

		encerrar_dialogo()
		return

	pode_avancar = false

	texto_dialogo.text = ""

	var texto = falas[fala_index]

	fala_index += 1

	await mostrar_texto(texto)


# =============================
# TEXTO ANIMADO
# =============================
func mostrar_texto(msg):

	for letra in msg:

		texto_dialogo.text += letra

		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


# =============================
# FINALIZAR
# =============================
func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# CHECK DO GATO
	if GameManager.etapa == 10 and not GameManager.encontrou_gato:

		GameManager.encontrou_gato = true

		if GameManager.objetivos:
			GameManager.objetivos.get_node("Check").show()

		GameManager.verificar_progresso()

		# começa seguir player
		if get_parent().has_method("comecar_seguir"):
			get_parent().comecar_seguir()


# =============================
# DETECÇÃO
# =============================
func _on_body_entered(body):

	if body.is_in_group("player") \
	and GameManager.etapa >= 10 \
	and GameManager.etapa < 14:

		player_perto = true

		label_interacao.text = "Pressione E para conversar"

		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false

		label_interacao.visible = false

		if falando:
			encerrar_dialogo()
