extends Node2D

@onready var sprite = $Sprite2D
@onready var bullet_marker = $Sprite2D/Bullet_Marker

@export var bullet_scene: PackedScene

var aim_direction := Vector2.RIGHT

func _process(delta):

	aim()
	shoot()


func aim():

	var aim_input = Vector2(
		Input.get_action_strength("p2_aim_right")
		- Input.get_action_strength("p2_aim_left"),

		Input.get_action_strength("p2_aim_down")
		- Input.get_action_strength("p2_aim_up")
	)

	print(aim_input)

	if aim_input.length() > 0.2:
		aim_direction = aim_input.normalized()

	rotation = aim_direction.angle()
	sprite.flip_v = aim_direction.x < 0


func shoot():

	if Input.is_action_just_pressed("p2_attack") and bullet_scene:

		var bullet = bullet_scene.instantiate()
		get_tree().current_scene.add_child(bullet)

		bullet.global_position = bullet_marker.global_position
		bullet.velocity = aim_direction * 250
