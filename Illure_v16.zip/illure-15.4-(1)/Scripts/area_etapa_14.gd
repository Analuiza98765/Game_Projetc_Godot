extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_body_entered(body):
	if body.is_in_group("player"):
		if GameManager.boneca_quebrada and \
				GameManager.ursinho_rasgado and \
				GameManager.bilhetes_socorro and \
				GameManager.sangue_chao and \
				GameManager.objetos_tortura and \
				GameManager.mesa_jantar:
			GameManager.avançar_etapa_14 = true
			GameManager.verificar_progresso()


func _on_body_exited(body: Node2D) -> void:
	pass # Replace with function body.
