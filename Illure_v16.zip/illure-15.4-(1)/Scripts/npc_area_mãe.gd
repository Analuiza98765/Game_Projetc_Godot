extends Area2D

# =============================
# UI GLOBAL
# =============================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =============================
# ESTADO
# =============================
var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []

# =============================
func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")
	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


func _process(_delta):

	if player_perto \
	and not falando \
	and not GameManager.em_dialogo \
	and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()

# =============================
# FALAS
# =============================
func pegar_falas():

	match GameManager.etapa:

		0:
			return [
				"Olá crianças, fiz uma lista com alguns itens importantes, que não estou encontrando, mas não consigo achá-la nessa bagunça da mudança.",
				"Poderiam encontrá-la e procurar o que falta?",
			]

		2:
			return [
				"Vocês acharam tudo!",
				"Obrigada crianças, coloquem essas coisas na cozinha, por favor."
			]

		3:
			return [
				"Mãe, você acha que vamos ficar aqui muito tempo?",
				"Se tudo der certo no trabalho, sim.",
				"Vamos dar uma volta pelo bairro, tá bom?",
				"Não, Lina! Vamos continuar trabalhando para terminar o mais rápido possível.",
				"Se o meu pai estivesse aqui ele me deixaria ir para onde quisesse!",
				"*SLAP*",
				"Lina....meu Deus, me desculpe, eu, eu...",
				"...",
				"(O irmão permanece em silêncio, como sempre desde que o pai sumiu.)"
			]

		4:
			return [
				"Lina, eu preciso me acalmar.",
				"Vai brincar um pouco, por favor."
			]

	return ["..."]

# =============================
# INICIAR
# =============================
func iniciar_dialogo():

	falando = true
	GameManager.iniciar_dialogo()

	label_interacao.visible = false
	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0
	falas = pegar_falas()

	proxima_fala()

# =============================
# AVANÇAR
# =============================
func proxima_fala():

	if fala_index >= falas.size():
		encerrar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]
	fala_index += 1

	await mostrar_texto(texto)

# =============================
# TEXTO
# =============================
func mostrar_texto(msg):

	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true

# =============================
# FINAL
# =============================
func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
		
	# diálogo da mãe após pegar os objetos
	if GameManager.etapa == 2:

		if GameManager.objetivos:
			GameManager.objetivos.get_node("Check").hide()
			GameManager.objetivos.get_node("Label").text = "Encontrar a caixa do pai"
			GameManager.falou_mae_etapa_2 = true
	
	elif GameManager.etapa == 3:
			GameManager.falar_mae_etapa3 = true
			GameManager.verificar_progresso()
	else:
		GameManager.verificar_progresso()
	

		
# =============================
# DETECÇÃO
# =============================

func _on_body_entered(body):

	if body.is_in_group("player"):
		player_perto = true
		label_interacao.text = "Pressione E para conversar"
		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):
		player_perto = false
		label_interacao.visible = false
		if falando:
			encerrar_dialogo()
