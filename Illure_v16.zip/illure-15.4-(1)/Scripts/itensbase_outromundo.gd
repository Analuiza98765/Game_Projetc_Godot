extends Area2D

@export var tipo_objeto = "foto"
@onready var sprite = $AnimatedSprite2D

var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

var player_perto = false
var mostrando_dialogo = false
var ja_interagiu = false


func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


func _process(_delta):

	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and not mostrando_dialogo \
	and not GameManager.em_dialogo:

		interagir()


# ==================================================
# INTERAÇÃO
# ==================================================
func interagir():

	if ja_interagiu:
		await mostrar_dialogo("...")
		return

	ja_interagiu = true
	mostrando_dialogo = true

	GameManager.iniciar_dialogo()
	GameManager.pegar_objeto(tipo_objeto)
	if sprite:
		sprite.hide()

	match tipo_objeto:

		"foto_outro":
			await mostrar_dialogo("Essa foto...")
			await mostrar_dialogo("Parece mais recente do que eu lembrava.Como se tivesse sido tirada depois que tudo mudou.")

		"caderno_outro":
			await mostrar_dialogo("Meus desenhos...")
			await mostrar_dialogo("Eles estão melhores aqui.Como se alguém tivesse continuado de onde eu parei.")

		"caixa_outro":
			await mostrar_dialogo("As coisas do pai...")
			await mostrar_dialogo("Estão todas arrumadas.Como se alguém tivesse cuidado delas esse tempo todo.")

	GameManager.verificar_progresso()

	mostrando_dialogo = false
	GameManager.encerrar_dialogo()


# ==================================================
# DIÁLOGO
# ==================================================
func mostrar_dialogo(msg):

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = msg

	await esperar_avancar()

func esperar_avancar():

	await get_tree().process_frame

	while true:

		await get_tree().process_frame

		if Input.is_action_just_pressed("interact"):
			break
			
# ==================================================
# DETECÇÃO
# ==================================================
func _on_body_entered(body):

	if body.is_in_group("player"):

		player_perto = true
		label_interacao.text = "Pressione 'E' para investigar"
		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false
		label_interacao.visible = false

		caixa_dialogo.visible = false
		texto_dialogo.visible = false

		mostrando_dialogo = false
		GameManager.encerrar_dialogo()
