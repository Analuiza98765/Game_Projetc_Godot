extends CharacterBody2D

@export var speed = 45
# =====================================
# VELOCIDADE
# =====================================
@export var velocidade_andar = 120

# =====================================
# DESTINOS
# =====================================

# vai pra porta
@export var destino_porta = Vector2(8, 1)

# confronto
@export var destino_confronto = Vector2(52, 1)

# arrombamento
@export var destino_arrombamento = Vector2(20, 4)

# =====================================
# ESTADOS
# =====================================
var direcao = Vector2.ZERO
var tempo = 0.0


func _ready():

	randomize()

	visible = false


func _physics_process(delta):

	# 1. diálogo (prioridade máxima)
	if GameManager.em_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# 2. pausa global (Area2D)
	if GameManager.npc_parado:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# 3. visibilidade
	if GameManager.etapa < 8:
		visible = false
		return

	if GameManager.etapa == 12:
		visible = false
		return

	visible = true

	# =====================================
	# MOMENTO 1
	# VAI PARA A PORTA
	# =====================================
	if GameManager.esperar_porta_mae:

		mover_para(destino_porta)

		return


	# =====================================
	# MOMENTO 2
	# CONFRONTO
	# =====================================
	if GameManager.confronto_mae:

		mover_para(destino_confronto)

		return
	# =====================================
	# MOVIMENTO ALEATÓRIO
	# =====================================
	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed

	move_and_slide()


# =====================================
# MOVER PARA PONTO
# =====================================
func mover_para(destino):

	var direcao_destino = (
		destino - global_position
	)

	# chegou
	if direcao_destino.length() <= 5:

		velocity = Vector2.ZERO

		# animação da porta
		if GameManager.pais_arrombaram_porta:

			if has_node("../porta"):
				get_node("../porta").play("abrir")

	else:

		velocity = (
			direcao_destino.normalized()
			* velocidade_andar
		)

	move_and_slide()


func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2(1,1).normalized(),
		Vector2(-1,1).normalized(),
		Vector2(1,-1).normalized(),
		Vector2(-1,-1).normalized(),
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]

	tempo = randf_range(0.8, 2.0)
