extends Node

signal objetivo_concluido
signal etapa_mudou(nova_etapa)

# ==================================================
# CONTROLE GLOBAL
# ==================================================
var etapa = 0
var em_dialogo = false
var encontrou_porta = false
var abriu_porta = false
var porta_outro_mundo = false
var falar_outra_mae = false
var falar_outro_pai = false
var encontrou_gato = false
# ==================================================
# ETAPAS
# ==================================================

# CASA NORMAL
# 0 = início / falar com a mãe
# 1 = procurar os objetos da lista
# 2 = encontrar caixa pai / falar com a mãe
# 3 = briga com a mãe / encontrar porta
# 4 = procurar chave
# 5 = entrar na porta

# CORREDOR
# 6 = entrar no outro mundo

# MUNDO PERFEITO
# 7 = encontrar objetos
# 8 = explorou os objetos da casa perfeita
# 9 = falou com a outra mãe
# 10 = falou com o outro pai

# GATO
# 11 = gato começou a seguir Lina

# ESTRANHEZA
# 13 = coisas estranhas acontecendo
# 14 = encontrou a porta secreta

# FINAL
# 15 = percebeu que precisa fugir
# 16 = pediu ajuda ao gato
# 17 = fuga
# 18 = final

# ==================================================
# CONTROLE DE ETAPA
# ==================================================
func avancar_etapa(nova_etapa):

	if nova_etapa > etapa:

		etapa = nova_etapa

		print("ETAPA ATUAL:", etapa)

		emit_signal("etapa_mudou", etapa)

# ==================================================
# CONTROLE DE DIÁLOGO
# ==================================================
func iniciar_dialogo():
	em_dialogo = true

func encerrar_dialogo():
	em_dialogo = false

# ==================================================
# ITENS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

var foto_familia = false
var caderno_lina = false
var caixa_pai = false
var chave_porta = false
var foto_outra_familia = false
var caderno_outra_lina = false
var caixa_outro_pai = false
# ==================================================
# RESET
# ==================================================
func novo_jogo():

	etapa = 0
	em_dialogo = false

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false
	chave_porta = false
	foto_outra_familia = false
	caderno_outra_lina = false
	caixa_outro_pai = false
	
	print("JOGO RESETADO")

# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista":
			item_lista = true

		"fita":
			item_fita = true

		"panela":
			item_panela = true

		"foto":
			foto_familia = true

		"caderno":
			caderno_lina = true

		"caixa_pai":
			caixa_pai = true

		"chave":
			chave_porta = true

			print("Pegou a chave")
		
		"foto_outro":
			foto_outra_familia = true
		
		"caderno_outro":
			caderno_outra_lina = true
		
		"caixa_outro":
			caixa_outro_pai = true
# ==================================================
# PROGRESSO
# ==================================================
func verificar_progresso():
	
	if etapa == 0:
		avancar_etapa(1)
		
	elif etapa == 1:
		if item_fita and item_panela and foto_familia and caderno_lina:
			avancar_etapa(2)
		
	elif etapa == 2:
		if caixa_pai:
			avancar_etapa(3)
	
	elif etapa == 3:
		if encontrou_porta:
			avancar_etapa(4)

	elif etapa == 4:
		if chave_porta:
			avancar_etapa(5)
	
	elif etapa == 5:
		if abriu_porta:
			avancar_etapa(6)
	
	elif etapa == 6:
		if porta_outro_mundo:
			avancar_etapa(7)

	elif etapa == 7:
		if foto_outra_familia and caderno_outra_lina and caixa_outro_pai:
			avancar_etapa(8)
	
	elif etapa == 8:
		if falar_outra_mae:
			avancar_etapa(9)
	
	elif etapa == 9:
		if falar_outro_pai:
			avancar_etapa(10)
	
	elif etapa == 10:
		if encontrou_gato:
			avancar_etapa(11)
			
func mostrar_objetivo_concluido():

	var aviso = get_tree().current_scene.get_node_or_null("CanvasLayer/AvisoObjetivo")

	if aviso == null:
		return

	aviso.text = "✔ Já peguei tudo\nA mamãe deve estar me esperando..."

	aviso.visible = true

	await get_tree().create_timer(3.0).timeout

	aviso.visible = false

func verificar_lista_completa():

	if item_fita and item_panela and foto_familia and caderno_lina:
		mostrar_objetivo_concluido()
		var lista = get_tree().current_scene.get_node_or_null("CanvasLayer/Lista")
		if lista:
			lista.hide()
