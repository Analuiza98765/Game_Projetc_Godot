extends Area2D

@onready var label_interacao: Label = $LabelInteracao
@onready var caixa_dialogo: Label = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo

var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []

# ==================================================
func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

# ==================================================
func _process(_delta):

	# INICIAR diálogo
	if player_perto and not falando and not GameManager.em_dialogo and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	# AVANÇAR diálogo
	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()

# ==================================================
# FALAS DO PAI
# ==================================================
func pegar_falas():

	match GameManager.etapa:

		10:
			return [
				"Oi, Lina.",
				"Sentiu minha falta?",
				"Eu sempre estive aqui.",
				"Esse lugar é melhor, não é?",
				"Você pode ficar aqui comigo..."
			]

		11:
			return [
				"Você ainda está aqui...",
				"Eu sabia que você não iria embora tão fácil."
			]

	return ["..."]

# ==================================================
# INICIAR DIÁLOGO
# ==================================================
func iniciar_dialogo():

	falando = true
	GameManager.em_dialogo = true

	label_interacao.visible = false
	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0
	falas = pegar_falas()

	proxima_fala()

# ==================================================
# AVANÇAR FALA
# ==================================================
func proxima_fala():

	if fala_index >= falas.size():
		encerrar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]
	fala_index += 1

	await mostrar_texto(texto)

# ==================================================
func mostrar_texto(msg):

	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true

# ==================================================
# FINAL DO DIÁLOGO
# ==================================================
func encerrar_dialogo():

	falando = false
	GameManager.em_dialogo = false
	pode_avancar = false
	fala_index = 0

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# PROGRESSÃO DO JOGO
	if GameManager.etapa == 10:
		GameManager.falou_com_pai()

# ==================================================
# DETECÇÃO DO PLAYER
# ==================================================
func _on_body_entered(body):
	if body.name == "Lina":
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione E para conversar"

func _on_body_exited(body):
	if body.name == "Lina":
		player_perto = false
		
		label_interacao.visible = false
		caixa_dialogo.visible = false
		texto_dialogo.visible = false
		
		falando = false
		GameManager.em_dialogo = false
