extends Area2D
@onready var label_interacao: Label = $LabelInteracao
@onready var caixa_dialogo: Label = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo


var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0

var falas = [
	"Você finalmente chegou.",
	"Estávamos esperando por você.",
	"Esta casa é sua... só que melhor.",
	"Aqui ninguém vai te ignorar.",
	"Por que não vai falar com seu pai também?"
]

# ==================================================
func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

# ==================================================
func _process(_delta):

	# Iniciar diálogo
	if player_perto and not falando and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	# Avançar diálogo
	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()

# ==================================================
func _on_body_entered(body):
	if body.is_in_group("player"):
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione E para conversar"

# ==================================================
func _on_body_exited(body):
	if body.is_in_group("player"):
		player_perto = false
		label_interacao.visible = false
		
		if falando:
			encerrar_dialogo()

# ==================================================
func iniciar_dialogo():

	if falando:
		return

	falando = true
	fala_index = 0
	pode_avancar = false

	label_interacao.visible = false
	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	proxima_fala()

# ==================================================
func proxima_fala():

	if fala_index >= falas.size():
		encerrar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]
	fala_index += 1

	await mostrar_texto(texto)

# ==================================================
func mostrar_texto(msg):

	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true

# ==================================================
func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
