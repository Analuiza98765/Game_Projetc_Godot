extends Area2D

var player_perto = false
var mostrando_dialogo = false

@onready var label_interacao = $"../CanvasLayer/LabelInteracao"
@onready var caixa_dialogo = $"../CanvasLayer/CaixadeDialogo"
@onready var texto_dialogo = $"../CanvasLayer/TextoDialogo"


func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

func _process(_delta):
	if player_perto and Input.is_action_just_pressed("interact") and not mostrando_dialogo:
		tentar_abrir()

# ==================================================
# LÓGICA DA PORTA
# ==================================================
func tentar_abrir():

	# 🔴 PRIMEIRA VEZ (libera busca da chave)
	if GameManager.etapa == 3:

		mostrar_dialogo("Está trancada...\nDeve haver uma chave.")

		GameManager.iniciar_busca_chave()


	# 🟠 JÁ SABE DA CHAVE
	elif GameManager.etapa == 4:

		mostrar_dialogo("Preciso encontrar a chave.")


	# 🟢 TEM A CHAVE
	elif GameManager.etapa == 5:

		GameManager.etapa = 6
		print("ETAPA 6 - Indo pro corredor")

		get_tree().change_scene_to_file("res://Scenes/corredor.tscn")


# ==================================================
# DIÁLOGO
# ==================================================
func esperar_input():
	while true:
		await get_tree().process_frame
		if Input.is_action_just_pressed("interact"):
			return
			
func mostrar_dialogo(msg):

	mostrando_dialogo = true

	if caixa_dialogo and texto_dialogo:
		caixa_dialogo.visible = true
		texto_dialogo.visible = true
		texto_dialogo.text = msg

	# ESPERA O JOGADOR APERTAR
	await esperar_input()

	if caixa_dialogo and texto_dialogo:
		caixa_dialogo.visible = false
		texto_dialogo.visible = false

	mostrando_dialogo = false




# ==================================================
# DETECÇÃO
# ==================================================
func _on_body_entered(body):
	if body.name == "Lina":
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione E para interagir"

func _on_body_exited(body):
	if body.name == "Lina":
		player_perto = false
		label_interacao.visible = false
