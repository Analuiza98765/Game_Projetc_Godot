extends Area2D

# ==================================================
# CONFIGURAÇÃO
# ==================================================

@export var tipo_objeto: String = "foto" 
# opções: "foto", "caderno", "caixa"

@export var usar_input := true

# ==================================================
# VARIÁVEIS
# ==================================================

var player_perto = false
var ja_interagiu = false
var mostrando_dialogo = false

# UI
@onready var caixa_dialogo = $"../CanvasLayer/CaixadeDialogo" # sem tipo OU usa Panel/ColorRect
@onready var texto_dialogo: Label = $"../CanvasLayer/TextoDialogo"
@onready var label_interacao: Label = $"../CanvasLayer/LabelInteracao"


# ==================================================
# READY
# ==================================================

func _ready():
	if label_interacao:
		label_interacao.visible = false

# ==================================================
# LOOP
# ==================================================

func _process(_delta):

	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and not ja_interagiu \
	and not mostrando_dialogo:
		interagir()

# ==================================================
# INTERAÇÃO
# ==================================================

func interagir():

	if GameManager.etapa != 8:
		return

	ja_interagiu = true
	mostrando_dialogo = true

	if label_interacao:
		label_interacao.visible = false

	var falas = pegar_falas()

	for fala in falas:
		await mostrar_fala(fala)

	mostrando_dialogo = false

	# registra interação na cena
	if get_tree().current_scene.has_method("registrar_interacao"):
		get_tree().current_scene.registrar_interacao()

	# 🔥 ativa evento estranho
	if GameManager.etapa == 8:
		GameManager.evento_estranho()

# ==================================================
# DIÁLOGOS
# ==================================================

func pegar_falas():

	match tipo_objeto:

		"foto":
			return [
				"Essa foto...",
				"Parece mais recente...",
				"Como se nada tivesse acontecido..."
			]

		"caderno":
			return [
				"Meus desenhos...",
				"Eles estão melhores aqui...",
				"Eu não lembro de ter feito isso..."
			]

		"caixa":
			return [
				"As coisas do pai...",
				"Estão todas arrumadas...",
				"Como se ele nunca tivesse ido embora..."
			]

		_:
			return ["..."]

# ==================================================
# MOSTRAR FALA
# ==================================================

func mostrar_fala(msg):

	if caixa_dialogo == null or texto_dialogo == null:
		print("ERRO: UI não encontrada")
		return

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = msg

	if usar_input:
		await esperar_input()
	else:
		await get_tree().create_timer(2.5).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

# ==================================================
# INPUT
# ==================================================

func esperar_input():
	while true:
		await get_tree().process_frame
		if Input.is_action_just_pressed("interact"):
			return

# ==================================================
# DETECÇÃO
# ==================================================

func _on_body_entered(body):
	if body.name == "Lina":
		player_perto = true

		if label_interacao:
			label_interacao.text = "Pressione E para interagir"
			label_interacao.visible = true

func _on_body_exited(body):
	if body.name == "Lina":
		player_perto = false

		if label_interacao:
			label_interacao.visible = false
