extends Node

signal objetivo_concluido
signal etapa_mudou(nova_etapa)

# ==================================================
# CONTROLE GLOBAL
# ==================================================
var etapa = 0
var em_dialogo = false

# ==================================================
# ETAPAS
# ==================================================
# 0 = início / falar com a mãe
# 1 = procurar objetos da casa
# 2 = encontrou tudo / voltar pra mãe
# 3 = briga / porta aparece
# 4 = procurar chave
# 5 = chave encontrada / porta pode abrir
# 6 = entrou no corredor
# 7 = entrou no mundo perfeito
# 8 = explorando mundo perfeito
# 9 = encontrou "outra mãe"
# 10 = encontrou o pai

# 11 = gato aparece
# 12 = gato segue
# 13 = eventos estranhos
# 14 = encontrou porta
# 15 = abriu porta

# 16 = confronto
# 17 = escolha final
# 18 = fuga
# 19 = final

# ==================================================
# CONTROLE DE ETAPA
# ==================================================
func avancar_etapa(nova_etapa):

	if nova_etapa > etapa:
		etapa = nova_etapa
		print("ETAPA ATUAL:", etapa)
		emit_signal("etapa_mudou", etapa)

# ==================================================
# CONTROLE DE DIÁLOGO
# ==================================================
func iniciar_dialogo():
	em_dialogo = true

func encerrar_dialogo():
	em_dialogo = false

# ==================================================
# EVENTOS PRINCIPAIS
# ==================================================
func falou_com_mae_inicio():
	if etapa == 0:
		avancar_etapa(1)

func entregou_objetos_mae():
	if etapa == 2:
		avancar_etapa(3)

func iniciar_busca_chave():
	if etapa == 3:
		avancar_etapa(4)

func falou_com_pai():
	if etapa == 10:
		avancar_etapa(11)
		print("Gato liberado")

# ==================================================
# GATO
# ==================================================
func encontrou_gato():
	if etapa == 11:
		avancar_etapa(12)
		print("Gato começou a seguir")

# ==================================================
# ESTRANHEZA
# ==================================================
func evento_estranho():
	if etapa == 12:
		avancar_etapa(13)
		print("Algo está errado...")

# ==================================================
# PORTA
# ==================================================
func encontrou_porta():
	if etapa == 13:
		avancar_etapa(14)
		print("Porta misteriosa encontrada")

func abriu_porta():
	if etapa == 14:
		avancar_etapa(15)
		print("Segredo descoberto")

# ==================================================
# FINAL
# ==================================================
func iniciou_confronto():
	if etapa == 15:
		avancar_etapa(16)

func escolha_final():
	if etapa == 16:
		avancar_etapa(17)

func iniciou_fuga():
	if etapa == 17:
		avancar_etapa(18)

func final_jogo():
	if etapa == 18:
		avancar_etapa(19)

# ==================================================
# ITENS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

var foto_familia = false
var caderno_lina = false
var caixa_pai = false

var chave_porta = false

# ==================================================
# RESET
# ==================================================
func novo_jogo():

	etapa = 0
	em_dialogo = false

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false

	chave_porta = false

	print("JOGO RESETADO")

# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista": item_lista = true
		"fita": item_fita = true
		"panela": item_panela = true
		"foto_familia": foto_familia = true
		"caderno": caderno_lina = true
		"caixa_pai": caixa_pai = true

		"chave":
			chave_porta = true
			print("Pegou a chave")

	verificar_progresso()

# ==================================================
# PROGRESSO
# ==================================================
func verificar_progresso():

	if etapa == 1:
		if item_lista and item_fita and item_panela:
			if foto_familia and caderno_lina and caixa_pai:
				avancar_etapa(2)
				mostrar_objetivo_concluido()

	if etapa == 4:
		if chave_porta:
			avancar_etapa(5)

# ==================================================
# AVISO
# ==================================================
func mostrar_objetivo_concluido():

	var aviso = get_tree().current_scene.get_node_or_null("CanvasLayer/AvisoObjetivo")

	if aviso == null:
		return

	aviso.text = "✔ Já peguei tudo\nA mamãe deve estar me esperando..."
	aviso.visible = true

	await get_tree().create_timer(3.0).timeout

	aviso.visible = false
