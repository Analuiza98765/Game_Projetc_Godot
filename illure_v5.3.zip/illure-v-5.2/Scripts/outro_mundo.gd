extends Node2D

@onready var caixa_dialogo = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo = $CanvasLayer/TextoDialogo

func _ready():

	await get_tree().process_frame

	if GameManager.etapa == 6:
		GameManager.avancar_etapa(7)
		print("ETAPA 7 - Mundo perfeito")

		await mostrar_dialogo_inicial()

		GameManager.avancar_etapa(8)
		print("ETAPA 8 - Explorar")

# =============================
# DIALOGO INICIAL
# =============================
func mostrar_dialogo_inicial():

	if caixa_dialogo == null or texto_dialogo == null:
		print("ERRO: UI não encontrada")
		return

	caixa_dialogo.visible = true
	texto_dialogo.visible = true

	texto_dialogo.text = "Isso... ainda é a minha casa?\nPor que tudo parece diferente?"

	await get_tree().create_timer(3.0).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
