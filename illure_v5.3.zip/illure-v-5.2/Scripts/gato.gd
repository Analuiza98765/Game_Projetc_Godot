extends CharacterBody2D

@export var speed = 130
@export var distancia_minima = 14
@export var offset_atras = Vector2(-20, 12)

var player = null

# =============================
func _ready():
	player = get_tree().get_first_node_in_group("player")

# =============================
func _physics_process(delta):

	# ❌ não faz nada se não achou player
	if player == null:
		return

	# ❌ só ativa depois que o gato "libera"
	if GameManager.etapa < 12:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# ❌ para durante diálogo
	if GameManager.em_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	var alvo = player.global_position + offset_atras
	var direcao = alvo - global_position
	var distancia = direcao.length()

	# Só segue se o player estiver andando
	if player.velocity.length() > 0:

		if distancia > distancia_minima:
			# movimento suavizado
			velocity = velocity.lerp(direcao.normalized() * speed, 0.2)
		else:
			velocity = Vector2.ZERO
	else:
		velocity = Vector2.ZERO

	move_and_slide()
