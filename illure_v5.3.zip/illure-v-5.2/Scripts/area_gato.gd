extends Area2D

# =============================
# UI
# =============================
@onready var caixade_dialogo = $"../CanvasLayer/CaixadeDialogo"
@onready var texto_dialogo = $"../CanvasLayer/TextoDialogo"
@onready var label_interacao = $"../CanvasLayer/LabelInteracao"

# =============================
# ESTADO
# =============================
var player_in_area = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []

# =============================
# READY
# =============================
func _ready():
	caixade_dialogo.visible = false
	texto_dialogo.visible = false
	label_interacao.visible = false

	# só aparece na etapa certa
	if GameManager.etapa < 11:
		visible = false

# =============================
# PROCESS
# =============================
func _process(_delta):

	# só funciona na etapa 11 (primeiro encontro)
	if GameManager.etapa != 11:
		return

	# evita conflito com outros diálogos
	if GameManager.em_dialogo:
		return

	if player_in_area and not falando and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()

# =============================
# FALAS DINÂMICAS
# =============================
func pegar_falas():

	match GameManager.etapa:

		11:
			return [
				"Nem tudo aqui é o que parece, garota.",
				"Esse lugar... não é real como você pensa.",
				"Preste atenção ao que muda ao seu redor.",
				"Se eu fosse você... não confiaria em ninguém daqui."
			]

	return ["..."]

# =============================
# AREA DETECTION
# =============================
func _on_body_entered(body):
	if body.is_in_group("player") and GameManager.etapa == 11:
		player_in_area = true
		label_interacao.text = "Pressione E para conversar"
		label_interacao.visible = true

func _on_body_exited(body):
	if body.is_in_group("player"):
		player_in_area = false
		label_interacao.visible = false

		if falando:
			encerrar_dialogo()

# =============================
# DIALOGO
# =============================
func iniciar_dialogo():

	falando = true
	GameManager.iniciar_dialogo()

	fala_index = 0
	falas = pegar_falas()

	label_interacao.visible = false
	caixade_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	proxima_fala()

func proxima_fala():

	if fala_index >= falas.size():
		finalizar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]
	fala_index += 1

	await mostrar_texto(texto)

func mostrar_texto(msg):

	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true

# =============================
# FINAL DO DIALOGO
# =============================
func finalizar_dialogo():

	encerrar_dialogo()

	# avanço correto da história
	if GameManager.etapa == 11:
		GameManager.encontrou_gato()

	# opcional: esconder interação depois
	label_interacao.visible = false

func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	caixade_dialogo.visible = false
	texto_dialogo.visible = false
