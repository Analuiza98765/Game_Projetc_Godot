extends Area2D

@export var tipo_objeto = "lista"

@onready var label_interacao: Label = $LabelInteracao
@onready var caixa_dialogo: Label = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo

var player_perto = false
var mostrando_dialogo = false
var ja_interagiu = false

var tempo_anim = 0.0
var apareceu = false

func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# começa invisível (pra chave)
	if tipo_objeto == "chave":
		modulate.a = 0
		visible = false

func _process(delta):

	# ==================================================
	# CONTROLE DA CHAVE (APARECER NA ETAPA 4)
	# ==================================================
	if tipo_objeto == "chave":

		if GameManager.etapa == 4:
			visible = true

			# Fade aparecer
			if not apareceu:
				modulate.a = lerp(modulate.a, 1.0, 0.05)
				if modulate.a > 0.95:
					apareceu = true

			# Animação flutuando
			tempo_anim += delta
			position.y += sin(tempo_anim * 2) * 0.2

		else:
			visible = false

	# ==================================================
	# INTERAÇÃO
	# ==================================================
	if player_perto and Input.is_action_just_pressed("investigate") and not mostrando_dialogo:
		interagir()


# ==================================================
# INTERAÇÃO DOS OBJETOS
# ==================================================
func interagir():

	match tipo_objeto:

		"lista":
			if not ja_interagiu:
				GameManager.pegar_objeto("lista")
				ja_interagiu = true
				mostrar_dialogo("Achei a lista que a mamãe pediu.")
			else:
				mostrar_dialogo("...")

		"fita":
			if not ja_interagiu:
				GameManager.pegar_objeto("fita")
				ja_interagiu = true
				mostrar_dialogo("Encontrei a fita adesiva.")
			else:
				mostrar_dialogo("...")

		"panela":
			if not ja_interagiu:
				GameManager.pegar_objeto("panela")
				ja_interagiu = true
				mostrar_dialogo("Aqui está a panela.")
			else:
				mostrar_dialogo("...")

		"foto":
			if not ja_interagiu:
				GameManager.pegar_objeto("foto_familia")
				ja_interagiu = true
				mostrar_dialogo("Essa foto foi tirada antes de... bem...")
			else:
				mostrar_dialogo("...")

		"caderno":
			if not ja_interagiu:
				GameManager.pegar_objeto("caderno")
				ja_interagiu = true
				mostrar_dialogo("Talvez eu desenhe um pouco depois.")
			else:
				mostrar_dialogo("...")

		"caixa_pai":
			if not ja_interagiu:
				GameManager.pegar_objeto("caixa_pai")
				ja_interagiu = true
				mostrar_dialogo("Essas coisas... eram do pai.\nEu achei que a mamãe tivesse jogado tudo isso fora.")
			else:
				mostrar_dialogo("...")

		"chave":
			if not ja_interagiu:
				GameManager.pegar_objeto("chave")
				ja_interagiu = true

				scale = Vector2(1.3, 1.3)

				await mostrar_dialogo("Uma chave... talvez abra aquela porta.")

				queue_free()
			else:
				await mostrar_dialogo("...")





# ==================================================
# DIÁLOGO
# ==================================================

func mostrar_dialogo(msg):

	mostrando_dialogo = true

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = msg

	await get_tree().create_timer(3.0).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	mostrando_dialogo = false

# ==================================================
# DETECÇÃO PLAYER
# ==================================================
func _on_body_entered(body):
	if body.name == "Lina":
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione I para investigar"

func _on_body_exited(body):
	if body.name == "Lina":
		player_perto = false
		label_interacao.visible = false
		caixa_dialogo.visible = false
		texto_dialogo.visible = false
		mostrando_dialogo = false
