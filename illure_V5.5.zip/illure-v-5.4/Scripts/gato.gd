extends CharacterBody2D

@export var speed = 130
@export var distancia_minima = 14
@export var offset_atras = Vector2(-20, 12)

var player: CharacterBody2D = null


func _ready():
	player = get_tree().get_first_node_in_group("player")

	# começa escondido se ainda não chegou na etapa 11
	_atualizar_estado_por_etapa(GameManager.etapa)

	# atualiza automaticamente quando a etapa mudar
	if GameManager.has_signal("etapa_mudou"):
		GameManager.etapa_mudou.connect(_on_etapa_mudou)


func _on_etapa_mudou(nova_etapa: int) -> void:
	_atualizar_estado_por_etapa(nova_etapa)


func _atualizar_estado_por_etapa(etapa_atual: int) -> void:
	# antes da etapa 11 o gato não existe visualmente
	visible = etapa_atual >= 11

	# (opcional) se você quiser que ele também "não colida" antes da 11:
	# process_mode = Node.PROCESS_MODE_DISABLED if etapa_atual < 11 else Node.PROCESS_MODE_INHERIT


func _physics_process(delta):

	# some totalmente antes da etapa 11 (e não processa follow)
	if GameManager.etapa < 11:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	if player == null:
		return

	# não segue na etapa 11 (apenas aparece e conversa)
	if GameManager.etapa < 12:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# para durante diálogo
	if GameManager.em_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# segue sempre a partir da etapa 12
	var alvo = player.global_position + offset_atras
	var direcao = alvo - global_position
	var distancia = direcao.length()

	# se quiser que ele siga MESMO quando a Lina estiver parada, tira esse IF
	if player.velocity.length() > 0:
		if distancia > distancia_minima:
			velocity = velocity.lerp(direcao.normalized() * speed, 0.2)
		else:
			velocity = Vector2.ZERO
	else:
		velocity = Vector2.ZERO

	move_and_slide()
