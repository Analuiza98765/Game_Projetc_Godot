extends CharacterBody2D

@export var speed = 45
@export var npc_parado = false

var direcao = Vector2.ZERO
var tempo = 0.0

func _ready():
	randomize()

func _physics_process(delta):

	# ✅ trava automaticamente durante diálogo (independente do npc_parado)
	if GameManager.em_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# ✅ trava se você marcar npc_parado no Inspector
	if npc_parado:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed
	move_and_slide()


func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2(1,1).normalized(),
		Vector2(-1,1).normalized(),
		Vector2(1,-1).normalized(),
		Vector2(-1,-1).normalized(),
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]
	tempo = randf_range(0.8, 2.0)
