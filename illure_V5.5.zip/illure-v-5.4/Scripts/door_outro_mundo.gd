extends Area2D

var player_inside = false

func _on_body_entered(body):
	if body.is_in_group("player"):
		player_inside = true

func _on_body_exited(body):
	if body.is_in_group("player"):
		player_inside = false

func _process(_delta):

	if player_inside and Input.is_action_just_pressed("ui_accept"):

		# Só entra no mundo perfeito se estiver na etapa correta
		if GameManager.etapa == 6:

			print("Entrando no mundo perfeito")

			GameManager.etapa = 7 # 👈 ESSENCIAL

			get_tree().change_scene_to_file("res://Scenes/outro_mundo.tscn")
