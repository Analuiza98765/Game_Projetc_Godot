extends Area2D

var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0

var falas = [
	"Você finalmente chegou.",
	"Estávamos esperando por você.",
	"Esta casa é sua... só que melhor.",
	"Aqui ninguém vai te ignorar.",
	"Por que não vai falar com seu pai também?"
]

func _ready():
	# ✅ pega UI DEPOIS que a cena existe (mais seguro)
	ui = get_tree().current_scene.get_node("CanvasLayer")
	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


func _process(_delta):
	if player_perto and not falando and not GameManager.em_dialogo and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()


func _on_body_entered(body):
	if body.is_in_group("player"):
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione E para conversar"


func _on_body_exited(body):
	if body.is_in_group("player"):
		player_perto = false
		label_interacao.visible = false

		if falando:
			encerrar_dialogo()


func iniciar_dialogo():
	if falando:
		return

	falando = true
	GameManager.iniciar_dialogo()

	fala_index = 0
	pode_avancar = false

	label_interacao.visible = false
	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	proxima_fala()


func proxima_fala():
	if fala_index >= falas.size():
		encerrar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]
	fala_index += 1

	await mostrar_texto(texto)


func mostrar_texto(msg):
	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


func encerrar_dialogo():
	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	# 🔥 garante que SUMA SEMPRE
	caixa_dialogo.visible = false
	texto_dialogo.visible = false
