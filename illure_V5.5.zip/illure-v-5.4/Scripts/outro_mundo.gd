extends Node2D

var ui
var caixa_dialogo
var texto_dialogo

func _ready():

	# ✅ pega UI global igual aos outros scripts
	ui = get_tree().current_scene.get_node("CanvasLayer")
	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")

	await get_tree().process_frame

	if GameManager.etapa == 6:
		GameManager.avancar_etapa(7)
		print("ETAPA 7 - Mundo perfeito")

		await mostrar_dialogo_inicial()

		GameManager.avancar_etapa(8)
		print("ETAPA 8 - Explorar")

# =============================
# DIALOGO INICIAL
# =============================
func mostrar_dialogo_inicial():

	if caixa_dialogo == null or texto_dialogo == null:
		print("ERRO: UI não encontrada")
		return

	# 🔥 trava o jogo durante o diálogo
	GameManager.iniciar_dialogo()

	caixa_dialogo.visible = true
	texto_dialogo.visible = true

	texto_dialogo.text = "Isso... ainda é a minha casa?\nPor que tudo parece diferente?"

	await get_tree().create_timer(3.0).timeout

	# 🔥 garante que some
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# 🔥 libera o jogo
	GameManager.encerrar_dialogo()
