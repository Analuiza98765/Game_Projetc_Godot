extends Area2D

# =============================
# UI GLOBAL
# =============================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =============================
# ESTADO
# =============================
var player_in_area = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []

func _ready():
	ui = get_tree().current_scene.get_node("CanvasLayer")
	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
	label_interacao.visible = false

	visible = GameManager.etapa >= 11

	if GameManager.has_signal("etapa_mudou"):
		GameManager.etapa_mudou.connect(_on_etapa_mudou)


func _on_etapa_mudou(nova_etapa: int) -> void:
	visible = nova_etapa >= 11

	if not visible:
		player_in_area = false
		label_interacao.visible = false

		if falando:
			encerrar_dialogo()


func _process(_delta):

	if GameManager.etapa != 11:
		return

	if GameManager.em_dialogo:
		return

	if player_in_area and not falando and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()


func pegar_falas():
	match GameManager.etapa:
		11:
			return [
				"Nem tudo aqui é o que parece, garota.",
				"Esse lugar... não é real como você pensa.",
				"Preste atenção ao que muda ao seu redor.",
				"Se eu fosse você... não confiaria em ninguém daqui."
			]
	return ["..."]


func _on_body_entered(body):
	if body.is_in_group("player") and GameManager.etapa == 11:
		player_in_area = true
		label_interacao.text = "Pressione E para conversar"
		label_interacao.visible = true


func _on_body_exited(body):
	if body.is_in_group("player"):
		player_in_area = false
		label_interacao.visible = false

		if falando:
			encerrar_dialogo()


func iniciar_dialogo():
	falando = true
	GameManager.iniciar_dialogo()

	fala_index = 0
	falas = pegar_falas()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	proxima_fala()


func proxima_fala():
	if fala_index >= falas.size():
		finalizar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]
	fala_index += 1

	await mostrar_texto(texto)


func mostrar_texto(msg):
	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


func finalizar_dialogo():
	encerrar_dialogo()

	if GameManager.etapa == 11:
		GameManager.encontrou_gato()

	label_interacao.visible = false


func encerrar_dialogo():
	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	# 🔥 GARANTE que a caixa some
	caixa_dialogo.visible = false
	texto_dialogo.visible = false
