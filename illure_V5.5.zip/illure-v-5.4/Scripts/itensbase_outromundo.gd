extends Area2D

# ==================================================
# CONFIGURAÇÃO
# ==================================================
@export var tipo_objeto: String = "foto"
@export var usar_input := true

# ==================================================
# VARIÁVEIS
# ==================================================
var player_perto = false
var ja_interagiu = false
var mostrando_dialogo = false

# UI GLOBAL
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# ==================================================
# READY
# ==================================================
func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


# ==================================================
# LOOP
# ==================================================
func _process(_delta):

	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and not mostrando_dialogo \
	and not GameManager.em_dialogo:
		interagir()


# ==================================================
# INTERAÇÃO
# ==================================================
func interagir():

	mostrando_dialogo = true
	GameManager.iniciar_dialogo()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true

	# ==================================================
	# ANTES DA ETAPA 7
	# ==================================================
	if GameManager.etapa < 7:

		texto_dialogo.text = "Não tem nada interessante aqui."

		if usar_input:
			await esperar_input()
		else:
			await get_tree().create_timer(2.0).timeout

		fechar_dialogo()
		return

	# ==================================================
	# SEGUNDA INTERAÇÃO
	# ==================================================
	if ja_interagiu:

		texto_dialogo.text = "..."

		if usar_input:
			await esperar_input()
		else:
			await get_tree().create_timer(1.5).timeout

		fechar_dialogo()
		return

	# ==================================================
	# PRIMEIRA INTERAÇÃO REAL
	# ==================================================
	ja_interagiu = true

	# REGISTRA NO GAMEMANAGER
	match tipo_objeto:

		"foto":
			GameManager.pegar_objeto("foto_familia")

		"caderno":
			GameManager.pegar_objeto("caderno")

		"caixa":
			GameManager.pegar_objeto("caixa_pai")

	var falas = pegar_falas()

	for fala in falas:

		texto_dialogo.text = fala

		if usar_input:
			await esperar_input()
		else:
			await get_tree().create_timer(2.5).timeout

	# ==================================================
	# FINAL
	# ==================================================
	fechar_dialogo()

	# progresso da cena
	if get_tree().current_scene.has_method("registrar_interacao"):
		get_tree().current_scene.registrar_interacao()


# ==================================================
# FECHAR DIÁLOGO
# ==================================================
func fechar_dialogo():

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	mostrando_dialogo = false

	GameManager.encerrar_dialogo()


# ==================================================
# DIÁLOGOS
# ==================================================
func pegar_falas():

	match tipo_objeto:

		"foto":
			return [
				"Essa foto...",
				"Parece mais recente...",
				"Como se nada tivesse acontecido..."
			]

		"caderno":
			return [
				"Meus desenhos...",
				"Eles estão melhores aqui...",
				"Eu não lembro de ter feito isso..."
			]

		"caixa":
			return [
				"As coisas do pai...",
				"Estão todas arrumadas...",
				"Como se ele nunca tivesse ido embora..."
			]

	return ["..."]


# ==================================================
# INPUT
# ==================================================
func esperar_input():

	# evita pular instantâneo
	while Input.is_action_pressed("interact"):
		await get_tree().process_frame

	# espera novo clique
	while true:

		await get_tree().process_frame

		if Input.is_action_just_pressed("interact"):
			return


# ==================================================
# DETECÇÃO
# ==================================================
func _on_body_entered(body):

	if body.is_in_group("player"):

		player_perto = true

		label_interacao.text = "Pressione E para interagir"
		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false

		label_interacao.visible = false

		caixa_dialogo.visible = false
		texto_dialogo.visible = false

		mostrando_dialogo = false

		GameManager.encerrar_dialogo()
