extends Node2D

@onready var fade = $CanvasLayer/Fade
@onready var frase = $CanvasLayer/FraseFinal

var alpha = 0.0
var iniciado := false
var esperando_input := false


func _ready():

	# garante que input funciona mesmo com UI/fade
	process_mode = Node.PROCESS_MODE_ALWAYS

	fade.color.a = 0
	frase.visible = false

	await get_tree().process_frame

	iniciar_final()


func _process(_delta):

	if not esperando_input:
		return

	if Input.is_action_just_pressed("interact"):

		esperando_input = false # <<< TRAVA IMPORTANTE

		print("E pressionado -> indo para relatório")

		get_tree().change_scene_to_file(
			"res://Scenes/final_relatorio.tscn"
		)


func iniciar_final():

	if iniciado:
		return

	iniciado = true

	# FADE IN
	while alpha < 1.0:

		alpha += 0.01
		fade.color.a = alpha

		await get_tree().create_timer(0.03).timeout


	await get_tree().create_timer(1.0).timeout


	# TEXTO 1
	await mostrar_frase(
		"FINAL CONQUISTADO:\n\nFINAL RUIM"
	)

	await get_tree().create_timer(2.0).timeout


	# TEXTO 2
	await mostrar_frase(
		"Obrigado por jogar a demo.\n\nPressione E para ver o relatório"
	)

	# libera input
	esperando_input = true


func mostrar_frase(texto):

	frase.visible = true
	frase.text = ""

	for letra in texto:

		frase.text += letra
		await get_tree().create_timer(0.04).timeout
