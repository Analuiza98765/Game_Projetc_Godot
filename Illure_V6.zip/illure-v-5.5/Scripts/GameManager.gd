extends Node

signal objetivo_concluido
signal etapa_mudou(nova_etapa)

# ==================================================
# CONTROLE GLOBAL
# ==================================================
var etapa = 0
var em_dialogo = false
var encontrou_porta = false
var abriu_porta = false
var porta_outro_mundo = false
var falar_outra_mae = false
var falar_outro_pai = false
# ==================================================
# ETAPAS
# ==================================================

# CASA NORMAL
# 0 = início / falar com a mãe
# 1 = procurar objetos da casa
# 2 = entregar objetos + encontrar caixa do pai
# 3 = briga com a mãe / porta aparece
# 4 = procurar chave
# 5 = chave encontrada

# CORREDOR
# 6 = entrou no corredor estranho

# MUNDO PERFEITO
# 7 = entrou no mundo perfeito
# 8 = explorar casa perfeita
# 9 = encontrou outra mãe
# 10 = falou com o pai

# GATO
# 11 = viu o gato
# 12 = gato falou e começou a seguir

# ESTRANHEZA
# 13 = coisas estranhas acontecendo
# 14 = encontrou a porta secreta

# FINAL
# 15 = percebeu que precisa fugir
# 16 = pediu ajuda ao gato
# 17 = fuga
# 18 = final

# ==================================================
# CONTROLE DE ETAPA
# ==================================================
func avancar_etapa(nova_etapa):

	if nova_etapa > etapa:

		etapa = nova_etapa

		print("ETAPA ATUAL:", etapa)

		emit_signal("etapa_mudou", etapa)

# ==================================================
# CONTROLE DE DIÁLOGO
# ==================================================
func iniciar_dialogo():
	em_dialogo = true

func encerrar_dialogo():
	em_dialogo = false

# ==================================================
# ITENS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

var foto_familia = false
var caderno_lina = false
var caixa_pai = false

var chave_porta = false

# ==================================================
# RESET
# ==================================================
func novo_jogo():

	etapa = 0
	em_dialogo = false

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false

	chave_porta = false

	print("JOGO RESETADO")

# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista":
			item_lista = true

		"fita":
			item_fita = true

		"panela":
			item_panela = true

		"foto":
			foto_familia = true

		"caderno":
			caderno_lina = true

		"caixa_pai":
			caixa_pai = true

		"chave":

			chave_porta = true

			print("Pegou a chave")
			
# ==================================================
# PROGRESSO
# ==================================================
func verificar_progresso():
	
	if etapa == 0:
		avancar_etapa(1)
		
	elif etapa == 1:
		if item_fita and item_panela and foto_familia and caderno_lina:
			avancar_etapa(2)
		
	elif etapa == 2:
		if caixa_pai:
			avancar_etapa(3)
	
	elif etapa == 3:
		if encontrou_porta:
			avancar_etapa(4)

	elif etapa == 4:
		if chave_porta:
			avancar_etapa(5)
	
	elif etapa == 5:
		if abriu_porta:
			avancar_etapa(6)
	
	elif etapa == 6:
		if porta_outro_mundo:
			avancar_etapa(7)

	elif etapa == 7:
		if foto_familia and caderno_lina and caixa_pai:
			avancar_etapa(8)
	
	elif etapa == 8:
		if falar_outra_mae:
			avancar_etapa(9)
	
	elif etapa == 9:
		if falar_outro_pai:
			avancar_etapa(10)
			
func mostrar_objetivo_concluido():

	var aviso = get_tree().current_scene.get_node_or_null("CanvasLayer/AvisoObjetivo")

	if aviso == null:
		return

	aviso.text = "✔ Já peguei tudo\nA mamãe deve estar me esperando..."

	aviso.visible = true

	await get_tree().create_timer(3.0).timeout

	aviso.visible = false

func verificar_lista_completa():

	if item_fita and item_panela and foto_familia and caderno_lina:
		mostrar_objetivo_concluido()
		var lista = get_tree().current_scene.get_node_or_null("CanvasLayer/Lista")
		if lista:
			lista.hide()
