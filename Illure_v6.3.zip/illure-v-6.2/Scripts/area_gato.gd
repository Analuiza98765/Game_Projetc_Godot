extends Area2D

# =============================
# UI GLOBAL
# =============================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =============================
# ESTADO
# =============================
var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []

# =============================
# READY
# =============================
func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# gato aparece na etapa 10
	visible = GameManager.etapa >= 10

	GameManager.etapa_mudou.connect(_on_etapa_mudou)


# =============================
# ETAPA MUDOU
# =============================
func _on_etapa_mudou(nova_etapa):

	visible = nova_etapa >= 10

	if not visible:

		player_perto = false
		label_interacao.visible = false

		if falando:
			encerrar_dialogo()


# =============================
# LOOP
# =============================
func _process(_delta):

	# gato só existe a partir da etapa 10
	if GameManager.etapa < 10:
		return

	# iniciar diálogo
	if player_perto \
	and not falando \
	and not GameManager.em_dialogo \
	and Input.is_action_just_pressed("interact"):

		iniciar_dialogo()

	# avançar fala
	elif falando \
	and pode_avancar \
	and Input.is_action_just_pressed("interact"):

		proxima_fala()


# =============================
# FALAS
# =============================
func pegar_falas():

	match GameManager.etapa:

		10:
			return [
				"Nem tudo aqui é o que parece, garota.",
				"Esse lugar... não é real como você pensa.",
				"Preste atenção ao que muda ao seu redor.",
				"Se eu fosse você... não confiaria em ninguém daqui."
			]

		11:
			return [
				"Agora eu vou com você.",
				"Você vai precisar de ajuda.",
				"E rápido."
			]

	return ["..."]


# =============================
# INICIAR DIÁLOGO
# =============================
func iniciar_dialogo():

	if falando:
		return

	falando = true

	GameManager.iniciar_dialogo()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0
	falas = pegar_falas()

	proxima_fala()


# =============================
# PRÓXIMA FALA
# =============================
func proxima_fala():

	if fala_index >= falas.size():

		encerrar_dialogo()
		return

	pode_avancar = false

	texto_dialogo.text = ""

	var texto = falas[fala_index]

	fala_index += 1

	await mostrar_texto(texto)


# =============================
# TEXTO ANIMADO
# =============================
func mostrar_texto(msg):

	for letra in msg:

		texto_dialogo.text += letra

		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


# =============================
# FINALIZAR
# =============================
func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	GameManager.encerrar_dialogo()

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# =====================================
	# PRIMEIRA CONVERSA COM GATO
	# =====================================
	if GameManager.etapa == 10:

		GameManager.encontrou_gato = true
		GameManager.verificar_progresso()

		# começa a seguir
		if get_parent().has_method("comecar_seguir"):

			get_parent().comecar_seguir()


# =============================
# DETECÇÃO
# =============================
func _on_body_entered(body):

	if body.is_in_group("player") \
	and GameManager.etapa >= 10:

		player_perto = true

		label_interacao.text = "Pressione E para conversar"

		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false

		label_interacao.visible = false

		if falando:
			encerrar_dialogo()
