extends CharacterBody2D

@export var speed = 35
@export var npc_parado = false

# =====================================
# DESTINOS
# =====================================
@export var velocidade_andar = 90

# vai pra porta
@export var destino_porta = Vector2(8, 1)

# perseguição
@export var destino_confronto = Vector2(52, 1)

# =====================================
# REFERÊNCIAS
# =====================================
var confronto_mae = false
var esperar_porta_mae = false

# =====================================
# NPC NORMAL
# =====================================
var direcao = Vector2.ZERO
var tempo = 0.0


func _ready():
	randomize()


func _physics_process(delta):

	# =====================================
	# MOMENTO 1
	# VAI PARA A PORTA
	# =====================================
	if GameManager.esperar_porta_mae:

		mover_para(destino_porta)

		return


	# =====================================
	# MOMENTO 2
	# CONFRONTO / PERSEGUIÇÃO
	# =====================================
	if GameManager.confronto_mae:

		mover_para(destino_confronto)

		return


	# =====================================
	# PARA DURANTE DIÁLOGO
	# =====================================
	if $Area2D.player_perto or GameManager.em_dialogo:

		velocity = Vector2.ZERO

		move_and_slide()

		return


	# =====================================
	# NPC PARADO
	# =====================================
	if npc_parado:

		velocity = Vector2.ZERO

		move_and_slide()

		return


	# =====================================
	# MOVIMENTO ALEATÓRIO
	# =====================================
	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed

	move_and_slide()


# =====================================
# MOVER PARA PONTO
# =====================================
func mover_para(destino):

	var direcao_destino = (
		destino - global_position
	)

	# chegou
	if direcao_destino.length() <= 5:

		velocity = Vector2.ZERO

	else:

		velocity = (
			direcao_destino.normalized()
			* velocidade_andar
		)

	move_and_slide()


func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]

	tempo = randf_range(1.0, 2.5)
