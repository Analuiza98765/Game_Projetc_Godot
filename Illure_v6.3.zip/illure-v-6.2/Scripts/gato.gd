extends CharacterBody2D

@export var speed = 130
@export var distancia_minima = 14
@export var offset_atras = Vector2(-20, 12)

var player: CharacterBody2D = null

# =====================================
# CONTROLE
# =====================================
var parado_dialogo = false


func _ready():

	player = get_tree().get_first_node_in_group("player")

	# começa escondido
	_atualizar_estado_por_etapa(GameManager.etapa)

	# atualiza automaticamente
	if GameManager.has_signal("etapa_mudou"):
		GameManager.etapa_mudou.connect(_on_etapa_mudou)


func _on_etapa_mudou(nova_etapa: int) -> void:

	_atualizar_estado_por_etapa(nova_etapa)


func _atualizar_estado_por_etapa(etapa_atual: int) -> void:

	# gato existe a partir da etapa 10
	visible = etapa_atual >= 10


func _physics_process(delta):

	# =====================================
	# ANTES DA ETAPA 10
	# =====================================
	if GameManager.etapa < 10:

		velocity = Vector2.ZERO
		move_and_slide()

		return


	if player == null:
		return


	# =====================================
	# ETAPA 10 = SÓ CONVERSA
	# =====================================
	if GameManager.etapa == 10:

		velocity = Vector2.ZERO
		move_and_slide()

		return


	# =====================================
	# PARA DURANTE DIÁLOGO
	# =====================================
	if GameManager.em_dialogo:

		velocity = Vector2.ZERO
		move_and_slide()

		return


	# =====================================
	# PARA NO DIÁLOGO FINAL DO PORÃO
	# =====================================
	if parado_dialogo:

		velocity = Vector2.ZERO
		move_and_slide()

		return


	# =====================================
	# SEGUE A LINA
	# =====================================
	var alvo = player.global_position + offset_atras

	var direcao = alvo - global_position

	var distancia = direcao.length()

	if player.velocity.length() > 0:

		if distancia > distancia_minima:

			velocity = velocity.lerp(
				direcao.normalized() * speed,
				0.2
			)

		else:

			velocity = Vector2.ZERO

	else:

		velocity = Vector2.ZERO

	move_and_slide()
