extends CharacterBody2D

@export var speed = 200

# =====================================
# PERSEGUIÇÃO
# =====================================
@export var velocidade_fuga = 260
@export var destino_fuga = Vector2(1200, 500)

var fuga_ativa = false


func _physics_process(delta):

	# =====================================
	# FUGA AUTOMÁTICA
	# =====================================
	if fuga_ativa:

		var direcao = (
			destino_fuga - global_position
		).normalized()

		velocity = direcao * velocidade_fuga

		move_and_slide()

		return


	# =====================================
	# MOVIMENTO NORMAL
	# =====================================
	var direction = Vector2.ZERO

	direction.x = (
		Input.get_action_strength("ui_right")
		- Input.get_action_strength("ui_left")
	)

	direction.y = (
		Input.get_action_strength("ui_down")
		- Input.get_action_strength("ui_up")
	)

	direction = direction.normalized()

	velocity = direction * speed

	move_and_slide()


func _on_area_2d_2_body_entered(body: Node2D) -> void:
	pass


func _on_door_volta_corredor_body_exited(body: Node2D) -> void:
	pass
