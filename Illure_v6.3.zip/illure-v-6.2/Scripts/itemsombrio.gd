extends Area2D

@export var tipo_objeto = "quadro_sombrio"

var player_perto = false
var ja_interagiu = false

var ui
var caixa_dialogo
var texto_dialogo
var label_interacao


func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")


func _process(_delta):

	# só existe na etapa 11
	visible = GameManager.etapa >= 11

	if GameManager.etapa != 11:
		return

	if player_perto \
	and Input.is_action_just_pressed("investigate") \
	and not GameManager.em_dialogo:

		interagir()


func interagir():

	if ja_interagiu:
		return

	ja_interagiu = true

	GameManager.iniciar_dialogo()

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	label_interacao.visible = false

	match tipo_objeto:

		# ==================================================
		# QUADRO SOMBRIO
		# ==================================================
		"quadro_sombrio":

			GameManager.pegar_objeto("quadro_sombrio")

			texto_dialogo.text = "O rosto no quadro... está diferente."


		# ==================================================
		# OLHO NA PAREDE
		# ==================================================
		"olho_na_parede":

			GameManager.pegar_objeto("olho_na_parede")

			texto_dialogo.text = "Tem um olho na parede..."


		# ==================================================
		# URSO EMPALHADO
		# ==================================================
		"urso_empalhado_sangrando":

			GameManager.pegar_objeto("urso_empalhado_sangrando")

			texto_dialogo.text = "O urso empalhado parece estar respirando enquanto sangra."


		# ==================================================
		# ESPELHO ESTRANHO
		# ==================================================
		"espelho_estranho":

			GameManager.pegar_objeto("espelho_estranho")

			texto_dialogo.text = "Meu reflexo... sorriu antes de mim."


	await get_tree().create_timer(2.5).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	GameManager.encerrar_dialogo()

	GameManager.verificar_progresso()


func _on_body_entered(body):

	if body.is_in_group("player"):

		player_perto = true

		label_interacao.visible = true
		label_interacao.text = "Pressione E para investigar"


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false
		label_interacao.visible = false
