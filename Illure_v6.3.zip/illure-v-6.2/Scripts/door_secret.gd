extends Area2D

var player_perto = false
var entrando = false

# UI
var ui
var caixa_dialogo
var texto_dialogo


func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
	entrando = true

func _process(_delta):

	# aparece só depois dos objetos estranhos
	visible = GameManager.etapa >= 12
	
	if GameManager.etapa != 12:
		return

	if entrando:
		return

	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and not GameManager.em_dialogo:

		entrar_porao()


# ==================================================
# ENTRAR NO PORÃO
# ==================================================
func entrar_porao():

	#entrando = true

	GameManager.iniciar_dialogo()

	caixa_dialogo.visible = true
	texto_dialogo.visible = true

	texto_dialogo.text = "Essa porta... não estava aqui antes."

	await get_tree().create_timer(2.0).timeout

	texto_dialogo.text = "Tem alguma coisa lá dentro..."

	await get_tree().create_timer(2.0).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	GameManager.encerrar_dialogo()
	

	# progresso
	GameManager.encontrou_porta_secreta = true

	GameManager.verificar_progresso()

	# vai pro porão
	get_tree().change_scene_to_file(
		"res://Scenes/porao.tscn"
	)


# ==================================================
# DETECÇÃO
# ==================================================
func _on_body_entered(body):

	if body.is_in_group("player"):
		player_perto = true


func _on_body_exited(body):

	if body.is_in_group("player"):
		player_perto = false
