extends CharacterBody2D

@export var speed = 28
@export var npc_parado = false

# =====================================
# VELOCIDADE
# =====================================
@export var velocidade_andar = 120

# =====================================
# DESTINOS
# =====================================

# vai pra porta
@export var destino_porta = Vector2(8, 2)

# confronto
@export var destino_confronto = Vector2(52, 2)

# =====================================
# ESTADOS
# =====================================
var confronto_pai = false
var esperar_porta_pai = false

# =====================================
# NPC NORMAL
# =====================================
var direcao = Vector2.ZERO
var tempo = 0.0


func _ready():

	randomize()

	# começa escondido
	visible = false


func _physics_process(delta):

	# =====================================
	# APARECE APÓS OUTRA MÃE
	# =====================================
	if GameManager.falar_outra_mae:

		visible = true

	else:

		visible = false
		return


	# =====================================
	# MOMENTO 1
	# VAI PARA A PORTA
	# =====================================
	if GameManager.esperar_porta_pai:

		mover_para(destino_porta)

		return


	# =====================================
	# MOMENTO 2
	# CONFRONTO
	# =====================================
	if GameManager.confronto_pai:

		mover_para(destino_confronto)

		return


	# =====================================
	# PARA DURANTE DIÁLOGO
	# =====================================
	if GameManager.em_dialogo:

		velocity = Vector2.ZERO

		move_and_slide()

		return


	# =====================================
	# NPC PARADO
	# =====================================
	if npc_parado:

		velocity = Vector2.ZERO

		move_and_slide()

		return


	# =====================================
	# MOVIMENTO ALEATÓRIO
	# =====================================
	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed

	move_and_slide()


# =====================================
# MOVER PARA PONTO
# =====================================
func mover_para(destino):

	var direcao_destino = (
		destino - global_position
	)

	# chegou
	if direcao_destino.length() <= 5:

		velocity = Vector2.ZERO

	else:

		velocity = (
			direcao_destino.normalized()
			* velocidade_andar
		)

	move_and_slide()


func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]

	tempo = randf_range(1.5, 3.0)
