#extends Area2D
#@onready var label_interacao: Label = $CanvasLayer/LabelInteracao
#@onready var caixa_dialogo: Label = $CanvasLayer/CaixadeDialogo
#@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo
#
#var player_perto = false
#var ja_testou_porta = false
#var mostrando_dialogo = false
#
#func _ready():
#
	#if label_interacao:
		#label_interacao.visible = false
#
	#if caixa_dialogo:
		#caixa_dialogo.visible = false
#
	#if texto_dialogo:
		#texto_dialogo.visible = false
#
#
#func _process(_delta):
#
	## só funciona depois da briga
	#if GameManager.etapa >= 3:
#
		#if player_perto and Input.is_action_just_pressed("interact"):
			#tentar_abrir()
#
## ==================================================
#func tentar_abrir():
#
	## SEM CHAVE
	#if GameManager.etapa == 3 and not ja_testou_porta:
#
		#ja_testou_porta = true
#
		#await mostrar_dialogo("A porta está trancada...")
#
		#await mostrar_dialogo("Preciso encontrar uma chave.")
#
		#GameManager.iniciar_busca_chave() # 👈 vira etapa 4
#
	## COM CHAVE
	#elif GameManager.etapa == 5:
#
		#await mostrar_dialogo("A chave encaixa...")
#
		#get_tree().change_scene_to_file("res://Scenes/outro_mundo.tscn")
#
## ==================================================
#func mostrar_dialogo(msg):
#
	#mostrando_dialogo = true
#
	#if caixa_dialogo and texto_dialogo:
		#caixa_dialogo.visible = true
		#texto_dialogo.visible = true
		#texto_dialogo.text = msg
#
	#await get_tree().create_timer(2.0).timeout
#
	#if caixa_dialogo and texto_dialogo:
		#caixa_dialogo.visible = false
		#texto_dialogo.visible = false
#
	#mostrando_dialogo = false
#
#
## ==================================================
#func _on_body_entered(body):
	#if body.name == "Lina":
		#player_perto = true
		#label_interacao.visible = true
		#label_interacao.text = "Pressione E para interagir"
#
#func _on_body_exited(body):
	#if body.name == "Lina":
		#player_perto = false
		#label_interacao.visible = false
