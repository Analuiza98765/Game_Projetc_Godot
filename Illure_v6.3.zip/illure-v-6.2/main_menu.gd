extends Control

func _ready() -> void:
	for button in get_tree().get_nodes_in_group("button"):
		button.connect("pressed", Callable(self, "on_button_pressed").bind(button))
		button.connect("mouse_exited", Callable(self, "mouse_interaction").bind(button, "exited"))
		button.connect("mouse_entered", Callable(self, "mouse_interaction").bind(button, "entered"))

func on_button_pressed(button: Button) -> void:
	match button.name:
		'Button_jogar':
			var _game: bool = get_tree().change_scene_to_file("res://Scenes/mundo_inicio.tscn")
		'Button_controles':
			var _controls: bool = get_tree().change_scene_to_file("res://Scenes/controles.tscn")
		'Button_company':
			var _opne_channel = OS.shell_open("https://github.com/Analuiza98765/Game_Projetc_Godot")
		'Button_sair':
			get_tree().quit()

func mouse_interaction(button: Button, state: String) -> void:
	match state:
		'exited':
			button.modulate.a = 1.0
		'entered':
			button.modulate.a = 0.5
			
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
