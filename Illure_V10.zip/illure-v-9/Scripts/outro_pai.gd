extends CharacterBody2D

@onready var sprite = $AnimatedSprite2D

@export var speed = 28

@export var velocidade_andar = 120

@export var destino_porta = Vector2(8, 2)

@export var destino_confronto = Vector2(52, 2)

var confronto_pai = false
var esperar_porta_pai = false
var npc_parado = false

var direcao = Vector2.ZERO
var tempo = 0.0

# =====================================
# ANIMAÇÃO
# =====================================
var ultima_direcao = "down"


func _ready():
	randomize()

	visible = false
	
	


func _physics_process(delta):

	# diálogo
	if GameManager.em_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# visibilidade
	if GameManager.etapa < 8:
		visible = false
		return

	if not GameManager.falar_outra_mae:
		visible = false
		return

	if GameManager.etapa == 12:
		visible = false
		return

	visible = true
	
	if npc_parado:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# vai pra porta
	if GameManager.esperar_porta_pai:
		mover_para(destino_porta)
		return

	# confronto
	if GameManager.confronto_pai:
		mover_para(destino_confronto)
		return

	# movimento normal
	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed
	move_and_slide()

	global_position = global_position.round()


# =====================================
# MOVER PARA PONTO
# =====================================
func mover_para(destino):

	var direcao_destino = (
		destino - global_position
	)

	if direcao_destino.length() <= 5:

		velocity = Vector2.ZERO

		# chegou na porta
		if GameManager.esperar_porta_pai:

			GameManager.pai_chegou_porta = true

	else:

		velocity = (
			direcao_destino.normalized()
			* velocidade_andar
		)

	animar_pai(velocity)

	move_and_slide()

	global_position = global_position.round()


# =====================================
# DIREÇÃO ALEATÓRIA
# =====================================
func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]

	tempo = randf_range(1.5, 3.0)


# =====================================
# ANIMAÇÃO
# =====================================
func animar_pai(direction):

	# =====================================
	# PARADO
	# =====================================
	if direction == Vector2.ZERO:

		var idle_anim = "idle_" + ultima_direcao

		if sprite.animation != idle_anim:
			sprite.play(idle_anim)

		return


	# =====================================
	# DIREÇÃO
	# =====================================
	if abs(direction.x) > abs(direction.y):

		if direction.x > 0:
			ultima_direcao = "right"
		else:
			ultima_direcao = "left"

	else:

		if direction.y > 0:
			ultima_direcao = "down"
		else:
			ultima_direcao = "up"


	# =====================================
	# WALK
	# =====================================
	var walk_anim = "walk_" + ultima_direcao

	if sprite.animation != walk_anim:
		sprite.play(walk_anim)


func _on_back_outromundo_door_area_entered(area: Area2D) -> void:
	pass
