extends CharacterBody2D

@export var speed = 200
@export var pedra_scene : PackedScene


func _ready():
	add_to_group("irmao")


func _physics_process(delta):

	var direction = Vector2.ZERO

	direction.x = (
		Input.get_action_strength("p2_right")
		- Input.get_action_strength("p2_left")
	)

	direction.y = (
		Input.get_action_strength("p2_down")
		- Input.get_action_strength("p2_up")
	)

	direction = direction.normalized()

	velocity = direction * speed

	move_and_slide()

	# ESTILINGUE
	if GameManager.etapa >= 13:

		if Input.is_action_just_pressed("p2_attack"):

			atirar_pedra()


func atirar_pedra():

	if pedra_scene == null:
		return

	var pedra = pedra_scene.instantiate()

	get_tree().current_scene.add_child(pedra)

	pedra.global_position = global_position

	var mouse = get_global_mouse_position()

	var direcao = (mouse - global_position).normalized()

	pedra.rotation = direcao.angle()

	pedra.velocity = direcao * 700
