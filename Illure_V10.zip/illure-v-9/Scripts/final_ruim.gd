extends Node2D

@onready var fade = $CanvasLayer/Fade
@onready var frase = $CanvasLayer/FraseFinal

var alpha = 0.0

func _ready():

	fade.color.a = 0

	frase.visible = false

	iniciar_final()


func iniciar_final():

	# escurece
	while alpha < 1.0:

		alpha += 0.01

		fade.color.a = alpha

		await get_tree().create_timer(0.03).timeout

	await get_tree().create_timer(1.0).timeout

	# primeira frase
	await mostrar_frase("FINAL CONQUISTADO:\n\nFINAL RUIM")

	await get_tree().create_timer(2.0).timeout

	# segunda frase
	await mostrar_frase("\nObrigado por jogar a demo.")


func mostrar_frase(texto):

	frase.visible = true
	frase.text = ""

	for letra in texto:

		frase.text += letra

		await get_tree().create_timer(0.04).timeout
