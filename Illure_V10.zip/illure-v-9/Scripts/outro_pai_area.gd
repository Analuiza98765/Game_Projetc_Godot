extends Area2D

# =============================
# UI GLOBAL
# =============================
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

# =============================
# ESTADO
# =============================
var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = []


# =============================
# READY
# =============================
func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


# =============================
# LOOP
# =============================
func _process(_delta):

	# iniciar diálogo
	if player_perto \
	and not falando \
	and not GameManager.em_dialogo \
	and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	# avançar fala
	elif falando \
	and pode_avancar \
	and Input.is_action_just_pressed("interact"):
		proxima_fala()


# =============================
# FALAS
# =============================
func pegar_falas():

	match GameManager.etapa:

		# ==================================================
		# PRIMEIRA CONVERSA
		# ==================================================
		9:
			return [
				"Oi, Lina.",
				"Sentiu minha falta?",
				"Eu sempre estive aqui.",
				"Esse lugar é melhor, não é?",
				"Você pode ficar aqui comigo..."
			]

		# ==================================================
		# DEPOIS
		# ==================================================
		10:
			return [
				"Você ainda está aqui...",
				"Eu sabia que você não iria embora tão fácil."
			]

		11:
			return [
				"O gato anda aparecendo muito por aqui...",
				"Eu não confio nele."
			]
			
		14:
			return [
				"Finalmente achei a saída...",
				"Eu só quero ir embora daqui...",
				"Você não vai embora.",
				"Lina...",
				"Esse lugar é sua casa agora.",
				"Me deixa sair!",
				"Não vamos deixar você fugir."
			]


# =============================
# INICIAR DIÁLOGO
# =============================
func iniciar_dialogo():

	if falando:
		return

	falando = true

	GameManager.iniciar_dialogo()

	label_interacao.visible = false

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = ""

	fala_index = 0
	falas = pegar_falas()

	proxima_fala()


# =============================
# PRÓXIMA FALA
# =============================
func proxima_fala():

	if fala_index >= falas.size():
		encerrar_dialogo()
		return

	pode_avancar = false
	texto_dialogo.text = ""

	var texto = falas[fala_index]

	fala_index += 1

	await mostrar_texto(texto)

# =============================
# TEXTO ANIMADO
# =============================
func mostrar_texto(msg):

	for letra in msg:

		texto_dialogo.text += letra

		await get_tree().create_timer(0.02).timeout

	pode_avancar = true


# =============================
# FINALIZAR
func encerrar_dialogo():

	falando = false

	GameManager.encerrar_dialogo()

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# diálogo da cutscene
	if GameManager.etapa == 13:
		GameManager.dialogo_terminou = true
		return

	# conversa normal
	if GameManager.etapa == 9:
		GameManager.falar_outro_pai = true
		GameManager.verificar_progresso()

# =============================
# DETECÇÃO
# =============================
func _on_body_entered(body):

	if body.is_in_group("player"):
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione E para conversar"
		get_parent().npc_parado = true

func _on_body_exited(body):

	if body.is_in_group("player"):
		player_perto = false
		label_interacao.visible = false
		get_parent().npc_parado = false
		if falando:
			encerrar_dialogo()
