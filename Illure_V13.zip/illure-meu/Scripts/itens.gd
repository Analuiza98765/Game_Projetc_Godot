extends Area2D

@export var tipo_objeto = "lista"

# UI GLOBAL
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

var player_perto = false
var mostrando_dialogo = false
var ja_interagiu = false

var tempo_anim = 0.0
var apareceu = false

func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")
	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# chave começa invisível
	if tipo_objeto == "chave":
		modulate.a = 0
		visible = false


func _process(delta):

	# =============================
	# CHAVE (APARECE NA ETAPA 4)
	# =============================
	if tipo_objeto == "chave":

		if GameManager.etapa == 4:

			visible = true

			# fade mais rápido
			if not apareceu:

				modulate.a = lerp(modulate.a, 1.0, 0.25)

				if modulate.a >= 0.95:
					modulate.a = 1.0
					apareceu = true

			# animação flutuando
			tempo_anim += delta
			position.y += sin(tempo_anim * 2.0) * 0.2

		else:

			visible = false

	# =============================
	# INTERAÇÃO
	# =============================
	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and not mostrando_dialogo \
	and not GameManager.em_dialogo:
		interagir()


# =============================
# INTERAÇÃO
# =============================
func interagir():

	if GameManager.etapa == 1:

		GameManager.iniciar_dialogo()

		mostrando_dialogo = true

		label_interacao.visible = false

		match tipo_objeto:

			# ==================================================
			# LISTA
			# ==================================================
			"lista":

				if not ja_interagiu:

					GameManager.pegar_objeto("lista")

					ja_interagiu = true

					$"../../CanvasLayer/Lista".show()

					await mostrar_dialogo("Achei a lista que a mamãe pediu.")

				else:

					await mostrar_dialogo("...")


			# ==================================================
			# FITA
			# ==================================================
			"fita":

				if GameManager.item_lista:

					if not ja_interagiu:

						GameManager.pegar_objeto("fita")

						ja_interagiu = true

						$"../../CanvasLayer/Lista".get_node("Fita_Check").show()

						await mostrar_dialogo("Encontrei a fita adesiva.")

						await GameManager.verificar_lista_completa()

					else:

						await mostrar_dialogo("...")

				else:

					await mostrar_dialogo("Preciso pegar a lista primeiro.")


			# ==================================================
			# PANELA
			# ==================================================
			"panela":

				if GameManager.item_lista:

					if not ja_interagiu:

						GameManager.pegar_objeto("panela")

						ja_interagiu = true

						$"../../CanvasLayer/Lista".get_node("Panela_Check").show()

						await mostrar_dialogo("Aqui está a panela.")

						await GameManager.verificar_lista_completa()

					else:

						await mostrar_dialogo("...")

				else:

					await mostrar_dialogo("Preciso pegar a lista primeiro.")


			# ==================================================
			# FOTO
			# ==================================================
			"foto":

				if GameManager.item_lista:

					if not ja_interagiu:

						GameManager.pegar_objeto("foto")

						ja_interagiu = true

						$"../../CanvasLayer/Lista".get_node("Foto_Check").show()

						await mostrar_dialogo("Essa foto foi tirada antes de... bem...")

						await GameManager.verificar_lista_completa()

					else:

						await mostrar_dialogo("...")

				else:

					await mostrar_dialogo("Preciso pegar a lista primeiro.")

			# ==================================================
			# CADERNO
			# ==================================================
			"caderno":

				if GameManager.item_lista:

					if not ja_interagiu:

						GameManager.pegar_objeto("caderno")

						ja_interagiu = true

						$"../../CanvasLayer/Lista".get_node("Caderno_Check").show()

						await mostrar_dialogo("Talvez eu desenhe um pouco depois.")

						await GameManager.verificar_lista_completa()

					else:

						await mostrar_dialogo("...")

				else:

					await mostrar_dialogo("Preciso pegar a lista primeiro.")
	
	
	elif GameManager.etapa == 2:

		if tipo_objeto == "caixa_pai":

			if not ja_interagiu:

				GameManager.pegar_objeto("caixa_pai")
				

				ja_interagiu = true

				await mostrar_dialogo(
					"Essas coisas... eram do pai.\nEu achei que a mamãe tivesse jogado tudo isso fora."
				)

			else:

				await mostrar_dialogo("...")
			
			GameManager.verificar_progresso()


	# ==================================================
	# ETAPA 4 - CHAVE
	# ==================================================
	elif GameManager.etapa == 4:

		if tipo_objeto == "chave":

			if not ja_interagiu:

				GameManager.pegar_objeto("chave")
				GameManager.chave_porta = true

				ja_interagiu = true

				await mostrar_dialogo("Uma chave... talvez abra aquela porta.")

			else:

				await mostrar_dialogo("...")

			GameManager.verificar_progresso()


		# ==================================================
		# FINAL
		# ==================================================
		caixa_dialogo.visible = false

		texto_dialogo.visible = false

		mostrando_dialogo = false

		GameManager.encerrar_dialogo()


# =============================
# DIÁLOGO
# =============================
func mostrar_dialogo(msg):

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = msg

	await get_tree().create_timer(1.0).timeout


# =============================
# DETECÇÃO
# =============================
func _on_body_entered(body):
	if body.is_in_group("player"):
		player_perto = true
		label_interacao.text = "Pressione E para investigar"
		label_interacao.visible = true

func _on_body_exited(body):
	if body.is_in_group("player"):
		player_perto = false
		label_interacao.visible = false

		# segurança extra
		caixa_dialogo.visible = false
		texto_dialogo.visible = false
		mostrando_dialogo = false

		GameManager.encerrar_dialogo()
