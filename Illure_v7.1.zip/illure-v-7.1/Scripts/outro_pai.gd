
extends CharacterBody2D

@export var speed = 28
@export var npc_parado = false

@export var velocidade_andar = 120

@export var destino_porta = Vector2(8, 2)

@export var destino_confronto = Vector2(52, 2)

@export var destino_arrombamento = Vector2(20, 5)

var confronto_pai = false
var esperar_porta_pai = false

var direcao = Vector2.ZERO
var tempo = 0.0


func _ready():
	randomize()

	visible = false


func _physics_process(delta):

	if GameManager.falar_outra_mae:

		visible = true

	else:

		visible = false
		return


	if GameManager.pais_arrombaram_porta:

		visible = true

		mover_para(destino_arrombamento)

		return


	if GameManager.esperar_porta_pai:

		mover_para(destino_porta)

		return


	if GameManager.confronto_pai:

		mover_para(destino_confronto)

		return


	if GameManager.em_dialogo:

		velocity = Vector2.ZERO

		move_and_slide()

		return


	if npc_parado:

		velocity = Vector2.ZERO

		move_and_slide()

		return


	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed

	move_and_slide()


func mover_para(destino):

	var direcao_destino = (
		destino - global_position
	)

	if direcao_destino.length() <= 5:

		velocity = Vector2.ZERO

		if GameManager.pais_arrombaram_porta:

			if has_node("../porta"):
				get_node("../porta").play("abrir")

	else:

		velocity = (
			direcao_destino.normalized()
			* velocidade_andar
		)

	move_and_slide()


func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]

	tempo = randf_range(1.5, 3.0)


func _on_back_outromundo_door_area_entered(area: Area2D) -> void:
	pass # Replace with function body.
