extends CharacterBody2D

@onready var player = get_tree().get_first_node_in_group("player")
@onready var sprite = $AnimatedSprite2D


@export var speed = 45
@export var velocidade_andar = 110
@export var destino_porta = Vector2(8, 1)
@export var destino_confronto = Vector2(52, 1)
@export var destino_arrombamento = Vector2(20, 4)

var stun_time := 0.0
var speed_multiplier := 1.0

var direcao = Vector2.ZERO
var tempo = 0.0
var npc_parado = false

# =====================================
# ANIMAÇÃO
# =====================================
var ultima_direcao = "down"


func _ready():

	randomize()

	visible = false


func _physics_process(delta):

	# STUN
	if stun_time > 0:
		stun_time -= delta
		velocity = Vector2.ZERO
		move_and_slide()
		return
	else:
		speed_multiplier = lerp(speed_multiplier, 1.0, 0.05)

	if GameManager.em_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	if npc_parado:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# visibilidade
	if GameManager.etapa < 8:
		visible = false
		return

	if GameManager.etapa >= 14:
		visible = false
		return

	visible = true

	if GameManager.esperar_porta_mae:
		mover_para(destino_porta)
		return

	if GameManager.confronto_mae:
		mover_para(destino_confronto)
		return

	if GameManager.pais_perseguem:
		perseguir_player()
		return

	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed * speed_multiplier
	move_and_slide()
# =====================================
# FUNÇÃO CHAMADA PELA BALA
# =====================================
func tomar_pedra():
	stun_time = 2.0
	speed_multiplier = 0.5


# =====================================
# MOVER PARA PONTO
# =====================================
func mover_para(destino):

	var direcao_destino = (
		destino - global_position
	)

	# chegou
	if direcao_destino.length() <= 5:

		velocity = Vector2.ZERO

		if GameManager.esperar_porta_mae:
			GameManager.mae_chegou_porta = true

		if GameManager.pais_arrombaram_porta:

			if has_node("../porta"):
				get_node("../porta").play("abrir")

	else:

		velocity = (
			direcao_destino.normalized()
			* velocidade_andar
		)

	animar_mae(velocity)

	move_and_slide()

	global_position = global_position.round()


# =====================================
# DIREÇÃO ALEATÓRIA
# =====================================
func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2(1,1).normalized(),
		Vector2(-1,1).normalized(),
		Vector2(1,-1).normalized(),
		Vector2(-1,-1).normalized(),
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]

	tempo = randf_range(0.8, 2.0)


# =====================================
# PERSEGUIR PLAYER
# =====================================
func perseguir_player():

	if player == null:
		return

	var direcao_player = (player.global_position - global_position).normalized()

	velocity = direcao_player * velocidade_andar * speed_multiplier

	animar_mae(velocity)

	move_and_slide()

	global_position = global_position.round()


# =====================================
# ANIMAÇÃO
# =====================================
func animar_mae(direction):

	# =====================================
	# PARADA
	# =====================================
	if direction == Vector2.ZERO:

		var idle_anim = "idle_" + ultima_direcao

		if sprite.animation != idle_anim:
			sprite.play(idle_anim)

		return


	# =====================================
	# DIREÇÃO
	# =====================================
	if abs(direction.x) > abs(direction.y):

		if direction.x > 0:
			ultima_direcao = "right"
		else:
			ultima_direcao = "left"

	else:

		if direction.y > 0:
			ultima_direcao = "down"
		else:
			ultima_direcao = "up"


	# =====================================
	# WALK
	# =====================================
	var walk_anim = "walk_" + ultima_direcao

	if sprite.animation != walk_anim:
		sprite.play(walk_anim)
