extends Node2D

@onready var sprite = $Sprite2D
@onready var bullet_marker = $Sprite2D/Bullet_Marker

@export var bullet_scene: PackedScene

@onready var game = get_tree().get_first_node_in_group("game_manager")


func _process(delta):

	if not game.irmao_jogando_pedra:
		return

	aim()
	shoot()


func aim():
	look_at(get_global_mouse_position())

	if get_global_mouse_position().x < global_position.x:
		sprite.scale.y = -1
	else:
		sprite.scale.y = 1


func shoot():
	if Input.is_action_just_pressed("p2_attack") and bullet_scene:

		var bullet = bullet_scene.instantiate()
		get_tree().current_scene.add_child(bullet)

		bullet.global_position = bullet_marker.global_position
		bullet.global_rotation = global_rotation

		var dir = (get_global_mouse_position() - global_position).normalized()
		bullet.velocity = dir * 700
