extends Area2D

var velocity = Vector2.ZERO
var damage = 20

func _ready():
	await get_tree().create_timer(3.0).timeout
	queue_free()


func _physics_process(delta):
	position += velocity * delta


func _on_body_entered(body):

	if body.has_method("tomar_pedra"):
		body.tomar_pedra()

	queue_free()
