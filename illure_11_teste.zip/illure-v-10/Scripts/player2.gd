extends CharacterBody2D

@export var speed = 200

func _ready():
	add_to_group("irmao")


func _physics_process(delta):

	var direction = Vector2.ZERO

	direction.x = Input.get_action_strength("p2_right") - Input.get_action_strength("p2_left")
	direction.y = Input.get_action_strength("p2_down") - Input.get_action_strength("p2_up")

	velocity = direction.normalized() * speed
	move_and_slide()

			
