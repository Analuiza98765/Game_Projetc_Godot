extends CharacterBody2D

@export var speed = 130
@export var distancia_minima = 14
@export var offset_atras = Vector2(-20, 12)

var player = null

func _ready():
	player = get_tree().get_first_node_in_group("player")

func _physics_process(delta):
	if player:
		var alvo = player.global_position + offset_atras
		var direcao = alvo - global_position
		var distancia = direcao.length()

		# Só segue se Lina estiver andando
		if player.velocity.length() > 0:
			if distancia > distancia_minima:
				velocity = direcao.normalized() * speed
			else:
				velocity = Vector2.ZERO
		else:
			velocity = Vector2.ZERO

	move_and_slide()
