extends Area2D

@onready var label_interacao = $LabelInteração
@onready var caixa_dialogo = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo = $CanvasLayer/TextoDialogo

var player_in_area = false
var falando = false
var pode_avancar = false
var fala_index = 0

var falas = [
	"Lina, já que você quer ajudar, pega aquela lista em cima da caixa.",
	"Tem algumas coisas que eu não tô achando... vê se você consegue encontrar pra mim.",
	"Vai me ajudar muito se você resolver isso."
]

func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

func _process(_delta):
	if player_in_area:
		if not falando and Input.is_action_just_pressed("interact"):
			iniciar_dialogo()
		elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
			proxima_fala()

func _on_body_entered(body):
	if body is CharacterBody2D:
		player_in_area = true
		label_interacao.text = "Pressione E para interagir"
		label_interacao.visible = true

func _on_body_exited(body):
	if body is CharacterBody2D:
		player_in_area = false
		label_interacao.visible = false
		
		if falando:
			encerrar_dialogo()

func iniciar_dialogo():
	falando = true
	pode_avancar = false
	fala_index = 0
	
	label_interacao.visible = false
	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	
	proxima_fala()

func proxima_fala():
	if fala_index >= falas.size():
		encerrar_dialogo()
		return
	
	var texto = falas[fala_index]
	fala_index += 1
	
	texto_dialogo.text = ""
	pode_avancar = false
	
	await mostrar_texto(texto)

func mostrar_texto(texto):
	for letra in texto:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout
	
	pode_avancar = true

func encerrar_dialogo():
	falando = false
	pode_avancar = false
	fala_index = 0
	
	caixa_dialogo.visible = false
	texto_dialogo.visible = false
	
	if player_in_area:
		label_interacao.visible = true


func _on_area_shape_entered(area_rid: RID, area: Area2D, area_shape_index: int, local_shape_index: int) -> void:
	pass # Replace with function body.


func _on_area_shape_exited(area_rid: RID, area: Area2D, area_shape_index: int, local_shape_index: int) -> void:
	pass # Replace with function body.


func _on_area_entered(area: Area2D) -> void:
	pass # Replace with function body.


func _on_area_exited(area: Area2D) -> void:
	pass # Replace with function body.
