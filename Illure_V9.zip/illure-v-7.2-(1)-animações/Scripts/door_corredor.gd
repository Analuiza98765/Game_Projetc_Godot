extends Area2D

var player_perto = false
var mostrando_dialogo = false
var dialogo_ativo = false

# UI GLOBAL
var ui
var caixa_dialogo
var texto_dialogo
var label_interacao

func _ready():
	
	ui = get_tree().current_scene.get_node("CanvasLayer")
	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


func _process(_delta):

	if mostrando_dialogo:
		return

	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and not GameManager.em_dialogo:

		tentar_abrir()

# ==================================================
# PORTA
# ==================================================
func tentar_abrir():

	if GameManager.etapa == 3:

		await mostrar_dialogo("Está trancada...\nDeve haver uma chave.")

		GameManager.encontrou_porta = true

		GameManager.verificar_progresso()

	# 🟠 AINDA NÃO TEM A CHAVE
	elif GameManager.etapa == 4:

		await mostrar_dialogo("Preciso encontrar a chave.")

	# 🟢 TEM A CHAVE
	elif GameManager.etapa == 5:

		GameManager.abriu_porta = true
		GameManager.verificar_progresso()

		GameManager.portas_atravessadas += 1

		await get_tree().process_frame
		get_tree().change_scene_to_file("res://Scenes/corredor.tscn")


# ==================================================
# DIÁLOGO
# ==================================================
func esperar_input():

	# espera soltar o botão
	while Input.is_action_pressed("interact"):
		await get_tree().process_frame

	# espera próximo clique
	while not Input.is_action_just_pressed("interact"):
		await get_tree().process_frame


func mostrar_dialogo(msg):

	dialogo_ativo = true
	mostrando_dialogo = true
	GameManager.iniciar_dialogo()

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	texto_dialogo.text = msg

	await esperar_input()

	if not dialogo_ativo:
		return

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	GameManager.encerrar_dialogo()
	mostrando_dialogo = false


# ==================================================
# DETECÇÃO
# ==================================================
func _on_body_entered(body):
	if body.is_in_group("player"):
		player_perto = true
		label_interacao.text = "Pressione E para interagir"
		label_interacao.visible = true

func _on_body_exited(body):

	if body.is_in_group("player"):
		player_perto = false
		label_interacao.visible = false

		if mostrando_dialogo:

			dialogo_ativo = false  # 🔴 cancela await

			caixa_dialogo.visible = false
			texto_dialogo.visible = false

			mostrando_dialogo = false
			GameManager.encerrar_dialogo()
