extends Control

func _ready():

	for node in $VBoxContainer.get_children():
		node.visible = false

	mostrar_relatorio()


func mostrar_relatorio():

	$VBoxContainer/Titulo.visible = true
	await get_tree().create_timer(0.5).timeout

	$VBoxContainer/Tempo.text = \
	"Tempo total: " + GameManager.formatar_tempo()

	$VBoxContainer/Tempo.visible = true
	await get_tree().create_timer(0.5).timeout


	$VBoxContainer/Objetos.text = \
	"Objetos encontrados: " + str(GameManager.objetos_encontrados)

	$VBoxContainer/Objetos.visible = true
	await get_tree().create_timer(0.5).timeout


	$VBoxContainer/Portas.text = \
	"Portas atravessadas: " + str(GameManager.portas_atravessadas)

	$VBoxContainer/Portas.visible = true
	await get_tree().create_timer(0.5).timeout


	$VBoxContainer/Distancia.text = \
	"Distância percorrida: " + GameManager.distancia_formatada()

	$VBoxContainer/Distancia.visible = true
	await get_tree().create_timer(0.5).timeout


	$VBoxContainer/Final.text = \
	"Final alcançado: " + GameManager.final_alcancado

	$VBoxContainer/Final.visible = true
