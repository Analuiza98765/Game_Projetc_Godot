extends CharacterBody2D

@export var speed = 35
@export var npc_parado = false

var falando = false
var direcao = Vector2.ZERO
var tempo = 0.0

func _ready():
	randomize()

func _physics_process(delta):

	# 🚫 trava se estiver falando
	if npc_parado or falando:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed
	move_and_slide()

func nova_direcao():
	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]
	tempo = randf_range(1.0, 2.5)
