# =========================================
# SCRIPT DA AREA2D DO PAI
# =========================================
extends Area2D

@onready var label_interacao: Label = $LabelInteracao
@onready var caixa_dialogo: Label = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo

var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0

var falas = [
	"Oi, Lina.",
	"Sentiu minha falta?",
	"Eu sempre estive aqui.",
	"Não precisa mais ficar triste.",
	"Agora estamos juntos de novo."
]

func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

func _process(_delta):

	if player_perto and not falando and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()

func _on_body_entered(body):
	if body.name == "Lina":
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione E para conversar"

func _on_body_exited(body):
	if body.name == "Lina":
		player_perto = false
		label_interacao.visible = false
		
		if falando:
			encerrar_dialogo()

func iniciar_dialogo():

	falando = true
	fala_index = 0

	label_interacao.visible = false
	caixa_dialogo.visible = true
	texto_dialogo.visible = true

	proxima_fala()

func proxima_fala():

	if fala_index < falas.size():

		pode_avancar = false
		texto_dialogo.text = ""

		var texto = falas[fala_index]
		fala_index += 1

		mostrar_texto(texto)

	else:
		encerrar_dialogo()

func mostrar_texto(msg):

	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true

func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	caixa_dialogo.visible = false
	texto_dialogo.visible = false
