extends CharacterBody2D

@export var speed = 200

func _physics_process(delta):
	var direction = Vector2.ZERO
	
	# Captura os inputs
	direction.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
	direction.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
	
	# Normaliza para não ficar mais rápido na diagonal
	direction = direction.normalized()
	
	# Aplica movimento
	velocity = direction * speed
	move_and_slide()
	
	print(GameManager.etapa)


func _on_area_2d_2_body_entered(body: Node2D) -> void:
	pass # Replace with function body.


func _on_door_volta_corredor_body_exited(body: Node2D) -> void:
	pass # Replace with function body.
