extends Node

# ==================================================
# GAME MANAGER - ILLURE
# AutoLoad: GameManager
# ==================================================

# ETAPAS
# 0 = início / falar com a mãe
# 1 = procurar objetos da casa
# 2 = encontrou tudo / voltar pra mãe
# 3 = briga / porta aparece
# 4 = procurar chave (só começa ao interagir com a porta)
# 5 = chave encontrada / porta pode abrir

var etapa = 0

# ==================================================
# ITENS PRINCIPAIS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

# ==================================================
# EXPLORAÇÃO
# ==================================================
var foto_familia = false
var caderno_lina = false
var caixa_pai = false

# ==================================================
# PORTA
# ==================================================
var chave_porta = false

# ==================================================
# RESETAR JOGO
# ==================================================
func novo_jogo():

	etapa = 0

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false

	chave_porta = false

	print("JOGO RESETADO")

# ==================================================
# FALOU COM A MÃE (ETAPA 0 → 1)
# ==================================================
func falou_com_mae_inicio():

	if etapa == 0:
		etapa = 1
		print("ETAPA 1 - Procurar objetos")

# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista":
			item_lista = true

		"fita":
			item_fita = true

		"panela":
			item_panela = true

		"foto_familia":
			foto_familia = true

		"caderno":
			caderno_lina = true

		"caixa_pai":
			caixa_pai = true

		"chave":
			chave_porta = true
			print("Pegou a chave")

	verificar_progresso()

# ==================================================
# VERIFICAR PROGRESSO AUTOMÁTICO
# ==================================================
func verificar_progresso():

	# ETAPA 1 → 2 (coletou tudo)
	if etapa == 1:
		if item_lista and item_fita and item_panela:
			if foto_familia and caderno_lina and caixa_pai:
				etapa = 2
				print("ETAPA 2 - Voltar pra mãe")

	# ETAPA 4 → 5 (pegou a chave)
	if etapa == 4:
		if chave_porta:
			etapa = 5
			print("ETAPA 5 - Porta pode ser aberta")

# ==================================================
# ENTREGOU ITENS PRA MÃE (ETAPA 2 → 3)
# ==================================================
func entregou_objetos_mae():

	if etapa == 2:
		etapa = 3
		print("ETAPA 3 - Briga / Porta liberada")

# ==================================================
# INICIAR BUSCA DA CHAVE (ETAPA 3 → 4)
# CHAMADO PELA PORTA, NÃO PELA MÃE
# ==================================================
func iniciar_busca_chave():

	if etapa == 3:
		etapa = 4
		print("ETAPA 4 - Procurar chave")
