extends Area2D

@onready var label_interacao: Label = $LabelInteracao
@onready var caixa_dialogo: Label = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo

var player_perto = false
var falando = false
var pode_avancar = false
var fala_index = 0
var falas = [] # 👈 IMPORTANTE

func _ready():
	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false

func _process(_delta):

	if player_perto and not falando and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()

# ==================================================
# FALAS POR ETAPA
# ==================================================
func pegar_falas():

	match GameManager.etapa:

		0:
			return [
				"Lina, já que você quer ajudar, pega aquela lista em cima da caixa.",
				"Tem algumas coisas que eu não tô achando…",
				"Vê se você consegue encontrar pra mim."
			]

		2:
			return [
				"Você encontrou tudo? Obrigada, Lina.",
				"Isso já ajuda bastante aqui em casa."
			]

		3:
			return [
				"Mãe… eu achei algumas coisas do pai.",
				"...",
				"Lina, nós já falamos sobre isso.",
				"Seu pai não está aqui.",
				"Mas eu só queria mostrar—",
				"EU DISSE QUE NÃO!",
				"...",
				"Ficar mexendo nisso não muda nada.",
				"Agora vai brincar, Lina."
			]

		4:
			return [
				"Lina, eu ainda estou ocupada.",
				"Vai brincar um pouco, por favor."
			]

	return ["..."]

# ==================================================
# SISTEMA DE DIÁLOGO
# ==================================================
func iniciar_dialogo():

	falando = true
	get_parent().falando = true

	label_interacao.visible = false
	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	fala_index = 0

	falas = pegar_falas() # 👈 CORRIGIDO

	proxima_fala()

func proxima_fala():

	if fala_index < falas.size():

		pode_avancar = false
		texto_dialogo.text = ""

		var texto = falas[fala_index]
		fala_index += 1

		mostrar_texto(texto)

	else:
		encerrar_dialogo()

func mostrar_texto(msg):

	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true

# ==================================================
# FINAL DO DIÁLOGO (CONTROLA O JOGO)
# ==================================================
func encerrar_dialogo():

	falando = false
	get_parent().falando = false
	pode_avancar = false
	fala_index = 0

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	# PROGRESSÃO DO JOGO
	if GameManager.etapa == 0:
		GameManager.falou_com_mae_inicio()

	elif GameManager.etapa == 2:
		GameManager.entregou_objetos_mae()

# ==================================================
# DETECÇÃO DO PLAYER
# ==================================================
func _on_body_entered(body):
	if body.name == "Lina":
		player_perto = true
		label_interacao.visible = true
		label_interacao.text = "Pressione E para conversar"

func _on_body_exited(body):
	if body.name == "Lina":
		player_perto = false
		
		label_interacao.visible = false
		caixa_dialogo.visible = false
		texto_dialogo.visible = false
		
		falando = false
		get_parent().falando = false # 👈 IMPORTANTE
