extends Node2D

@onready var sprite = $Sprite2D
@onready var bullet_marker = $Sprite2D/Bullet_Marker

@export var bullet_scene: PackedScene

var aim_direction := Vector2.RIGHT
var use_mouse := false

func _process(delta):
	handle_input_mode()
	aim()
	shoot()


func handle_input_mode():
	# Se mexer o mouse, ativa modo mouse
	if Input.get_last_mouse_velocity().length() > 0:
		use_mouse = true

	# Se usar controle/teclado, ativa modo controle
	var controller_input = Vector2(
		Input.get_action_strength("p2_aim_right") - Input.get_action_strength("p2_aim_left"),
		Input.get_action_strength("p2_aim_down") - Input.get_action_strength("p2_aim_up")
	)

	if controller_input.length() > 0.1:
		use_mouse = false


func aim():

	if use_mouse:
		# ---- MOUSE AIM ----
		var mouse_pos = get_global_mouse_position()
		aim_direction = (mouse_pos - global_position).normalized()

	else:
		# ---- CONTROLLER AIM ----
		var aim_input = Vector2(
			Input.get_action_strength("p2_aim_right") - Input.get_action_strength("p2_aim_left"),
			Input.get_action_strength("p2_aim_down") - Input.get_action_strength("p2_aim_up")
		)

		if aim_input.length() > 0.2:
			aim_direction = aim_input.normalized()

	rotation = aim_direction.angle()
	sprite.flip_v = aim_direction.x < 0


func shoot():
	if Input.is_action_just_pressed("p2_attack") and bullet_scene:

		var bullet = bullet_scene.instantiate()
		get_tree().current_scene.add_child(bullet)

		bullet.global_position = bullet_marker.global_position
		bullet.velocity = aim_direction * 250
