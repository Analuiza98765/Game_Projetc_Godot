extends Area2D

# =============================
# REFERÊNCIAS UI
# =============================
@onready var caixade_dialogo: Label = $"../CanvasLayer/CaixadeDialogo"
@onready var texto_dialogo: Label = $"../CanvasLayer/TextoDialogo"
@onready var label_interacao: Label = $"../CanvasLayer/LabelInteraçao"


# =============================
# ESTADO
# =============================
var player_in_area = false
var falando = false
var pode_avancar = false
var fala_index = 0

# =============================
# FALAS DO GATO (ETAPA 11)
# =============================
var falas = [
	"Nem tudo aqui é o que parece, garota.",
	"Esse lugar... não é real como você pensa.",
	"Preste atenção ao que muda ao seu redor.",
	"Se eu fosse você... não confiaria em ninguém daqui."
]

# =============================
# READY
# =============================
func _ready():
	caixade_dialogo.visible = false
	texto_dialogo.visible = false
	label_interacao.visible = false

	# Gato só aparece na etapa 11
	if GameManager.etapa != 11:
		visible = false

# =============================
# PROCESS
# =============================
func _process(_delta):

	# Só funciona na etapa correta
	if GameManager.etapa != 11:
		return

	if player_in_area and not falando and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()

	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()

# =============================
# AREA DETECTION
# =============================
func _on_body_entered(body):
	if body.name == "Lina" and GameManager.etapa == 11:
		player_in_area = true
		label_interacao.text = "Pressione E para conversar"
		label_interacao.visible = true

func _on_body_exited(body):
	if body.name == "Lina":
		player_in_area = false
		label_interacao.visible = false

		if falando:
			encerrar_dialogo()

# =============================
# DIALOGO
# =============================
func iniciar_dialogo():

	falando = true
	fala_index = 0

	label_interacao.visible = false
	caixade_dialogo.visible = true
	texto_dialogo.visible = true

	proxima_fala()

func proxima_fala():

	if fala_index < falas.size():

		pode_avancar = false
		texto_dialogo.text = ""

		var texto = falas[fala_index]
		fala_index += 1

		await mostrar_texto(texto)

	else:
		# FINAL DO DIALOGO → AVANÇA ETAPA
		GameManager.etapa = 12
		print("ETAPA 12 - Começou a desconfiar")

		encerrar_dialogo()

func mostrar_texto(msg):

	for letra in msg:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout

	pode_avancar = true

func encerrar_dialogo():

	falando = false
	pode_avancar = false
	fala_index = 0

	caixade_dialogo.visible = false
	texto_dialogo.visible = false
