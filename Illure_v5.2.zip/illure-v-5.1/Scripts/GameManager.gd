extends Node

signal objetivo_concluido
signal etapa_mudou(nova_etapa)

# ==================================================
# ETAPAS
# ==================================================
# 0 = início / falar com a mãe
# 1 = procurar objetos da casa
# 2 = encontrou tudo / voltar pra mãe
# 3 = briga / porta aparece
# 4 = procurar chave
# 5 = chave encontrada / porta pode abrir
# 6 = entrou no corredor
# 7 = entrou no mundo perfeito
# 8 = explorando mundo perfeito
# 9 = encontrou "outra mãe"
# 10 = encontrou o pai
# 11 = encontrou o gato (liberado para interação)
# 12 = começou a desconfiar (gato segue)
# 13 = encontrou porta trancada (mundo perfeito)
# 14 = abriu porta / descobriu segredo
# 15 = confronto com outra mãe
# 16 = escolha final
# 17 = fuga
# 18 = final

var etapa = 0

# ==================================================
# FUNÇÃO CENTRAL DE ETAPA
# ==================================================
func avancar_etapa(nova_etapa):

	if nova_etapa > etapa:
		etapa = nova_etapa
		print("ETAPA ATUAL:", etapa)
		emit_signal("etapa_mudou", etapa)

# ==================================================
# EVENTOS DA HISTÓRIA
# ==================================================

func falou_com_mae_inicio():

	if etapa == 0:
		avancar_etapa(1)
		print("ETAPA 1 - Procurar objetos")

func entregou_objetos_mae():

	if etapa == 2:
		avancar_etapa(3)
		print("ETAPA 3 - Briga / Porta liberada")

func iniciar_busca_chave():

	if etapa == 3:
		avancar_etapa(4)
		print("ETAPA 4 - Procurar chave")

func falou_com_pai():

	if etapa == 10:
		avancar_etapa(11)
		print("ETAPA 11 - Gato liberado")

func encontrou_gato():

	if etapa == 11:
		avancar_etapa(12)
		print("ETAPA 12 - Começou a desconfiar")

# ==================================================
# ITENS PRINCIPAIS
# ==================================================
var item_lista = false
var item_fita = false
var item_panela = false

# ==================================================
# EXPLORAÇÃO
# ==================================================
var foto_familia = false
var caderno_lina = false
var caixa_pai = false

# ==================================================
# PORTA
# ==================================================
var chave_porta = false

# ==================================================
# RESETAR JOGO
# ==================================================
func novo_jogo():

	etapa = 0

	item_lista = false
	item_fita = false
	item_panela = false

	foto_familia = false
	caderno_lina = false
	caixa_pai = false

	chave_porta = false

	print("JOGO RESETADO")

# ==================================================
# PEGAR OBJETO
# ==================================================
func pegar_objeto(nome):

	match nome:

		"lista":
			item_lista = true

		"fita":
			item_fita = true

		"panela":
			item_panela = true

		"foto_familia":
			foto_familia = true

		"caderno":
			caderno_lina = true

		"caixa_pai":
			caixa_pai = true

		"chave":
			chave_porta = true
			print("Pegou a chave")

	verificar_progresso()

# ==================================================
# VERIFICAR PROGRESSO
# ==================================================
func verificar_progresso():

	# ETAPA 1 → 2
	if etapa == 1:
		if item_lista and item_fita and item_panela:
			if foto_familia and caderno_lina and caixa_pai:
				avancar_etapa(2)
				print("ETAPA 2 - Voltar pra mãe")
				mostrar_objetivo_concluido()

	# ETAPA 4 → 5
	if etapa == 4:
		if chave_porta:
			avancar_etapa(5)
			print("ETAPA 5 - Porta pode ser aberta")

# ==================================================
# AVISO NA TELA
# ==================================================
func mostrar_objetivo_concluido():

	var aviso = get_tree().current_scene.get_node_or_null("CanvasLayer/AvisoObjetivo")

	if aviso == null:
		print("AvisoObjetivo não encontrado!")
		return

	aviso.text = "✔ Já peguei tudo\nA mamãe deve estar me esperando..."
	aviso.visible = true

	await get_tree().create_timer(3.0).timeout

	aviso.visible = false
