extends CharacterBody2D

@export var speed = 200
@export var pedra_scene : PackedScene

@onready var sprite = $AnimatedSprite2D

# =====================================
# ANIMAÇÃO
# =====================================
var ultima_direcao = "down"


func _ready():

	add_to_group("irmao")


func _physics_process(delta):

	var direction = Vector2.ZERO

	direction.x = (
		Input.get_action_strength("p2_right")
		- Input.get_action_strength("p2_left")
	)

	direction.y = (
		Input.get_action_strength("p2_down")
		- Input.get_action_strength("p2_up")
	)

	direction = direction.normalized()

	velocity = direction * speed

	# =====================================
	# ANIMAÇÃO
	# =====================================
	animar(direction)

	move_and_slide()

	global_position = global_position.round()


	# =====================================
	# ESTILINGUE
	# =====================================
	if GameManager.etapa >= 13:

		if Input.is_action_just_pressed("p2_attack"):

			atirar_pedra()


# =====================================
# PEDRA
# =====================================
func atirar_pedra():

	if pedra_scene == null:
		return

	var pedra = pedra_scene.instantiate()

	get_tree().current_scene.add_child(pedra)

	pedra.global_position = global_position

	var mouse = get_global_mouse_position()

	var direcao = (mouse - global_position).normalized()

	pedra.rotation = direcao.angle()

	pedra.velocity = direcao * 700


# =====================================
# ANIMAÇÃO
# =====================================
func animar(direction):

	# =====================================
	# IDLE
	# =====================================
	if direction == Vector2.ZERO:

		var idle_anim = "idle_" + ultima_direcao

		if sprite.animation != idle_anim:
			sprite.play(idle_anim)

		return


	# =====================================
	# DIREÇÃO
	# =====================================
	if abs(direction.x) > abs(direction.y):

		if direction.x > 0:
			ultima_direcao = "right"
		else:
			ultima_direcao = "left"

	else:

		if direction.y > 0:
			ultima_direcao = "down"
		else:
			ultima_direcao = "up"


	# =====================================
	# WALK
	# =====================================
	var walk_anim = "walk_" + ultima_direcao

	if sprite.animation != walk_anim:
		sprite.play(walk_anim)
