extends Node2D

@onready var fade = $CanvasLayer/Fade
@onready var frase = $CanvasLayer/FraseFinal

var alpha = 0.0
var iniciado := false

func iniciar_final():
	if iniciado:
		return

	iniciado = true

	# escurece
	while alpha < 1.0:
		alpha += 0.01
		fade.color.a = alpha
		await get_tree().create_timer(0.03).timeout

	await get_tree().create_timer(1.0).timeout

	await mostrar_frase("FINAL CONQUISTADO:\n\nFINAL RUIM")
	await get_tree().create_timer(2.0).timeout

	await mostrar_frase("\nObrigado por jogar a demo.")

	await get_tree().create_timer(2.0).timeout

	get_tree().change_scene_to_file("res://Scenes/relatorio.tscn")


func mostrar_frase(texto):

	frase.visible = true
	frase.text = ""

	for letra in texto:

		frase.text += letra

		await get_tree().create_timer(0.04).timeout

func _ready():
	fade.color.a = 0
	frase.visible = false

	await get_tree().process_frame
	iniciar_final()
