extends CharacterBody2D

@export var speed = 200

# =====================================
# PERSEGUIÇÃO
# =====================================
@export var velocidade_fuga = 260
@export var destino_fuga = Vector2(1200, 500)

var fuga_ativa = false
var ultima_posicao

func _ready():
	ultima_posicao = global_position
# =====================================
# ANIMAÇÃO
# =====================================
@onready var sprite = $AnimatedSprite2D

var ultima_direcao = "down"


func _physics_process(delta):
	var distancia = global_position.distance_to(ultima_posicao)

	GameManager.distancia_andada += distancia

	ultima_posicao = global_position
	# =====================================
	# FUGA AUTOMÁTICA
	# =====================================
	if fuga_ativa:

		var direcao = (
			destino_fuga - global_position
		).normalized()

		velocity = direcao * velocidade_fuga

		animar_personagem(direcao)

		move_and_slide()

		return


	# =====================================
	# MOVIMENTO NORMAL
	# =====================================
	var direction = Vector2.ZERO

	direction.x = (
		Input.get_action_strength("ui_right")
		- Input.get_action_strength("ui_left")
	)

	direction.y = (
		Input.get_action_strength("ui_down")
		- Input.get_action_strength("ui_up")
	)

	direction = direction.normalized()

	velocity = direction * speed

	animar_personagem(direction)

	move_and_slide()
	global_position = global_position.round()


func animar_personagem(direction):

	# =====================================
	# PARADO
	# =====================================
	if direction == Vector2.ZERO:

		var idle_anim = "idle_" + ultima_direcao

		if sprite.animation != idle_anim:
			sprite.play(idle_anim)

		return


	# =====================================
	# DIREÇÕES
	# =====================================
	if abs(direction.x) > abs(direction.y):

		if direction.x > 0:
			ultima_direcao = "right"
		else:
			ultima_direcao = "left"

	else:

		if direction.y > 0:
			ultima_direcao = "down"
		else:
			ultima_direcao = "up"


	# =====================================
	# WALK
	# =====================================
	var walk_anim = "walk_" + ultima_direcao

	if sprite.animation != walk_anim:
		sprite.play(walk_anim)


func _on_area_2d_2_body_entered(body: Node2D) -> void:
	pass


func _on_door_volta_corredor_body_exited(body: Node2D) -> void:
	pass
