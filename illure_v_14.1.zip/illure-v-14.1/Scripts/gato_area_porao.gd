extends Area2D


func _on_body_entered(body):

	if body.is_in_group("player"):

		get_parent().player_perto = true

		if GameManager.etapa == 15 and !get_parent().ja_falou:

			get_parent().label_interacao.visible = true

			get_parent().label_interacao.text = "Pressione E para falar"


func _on_body_exited(body):

	if body.is_in_group("player"):

		get_parent().player_perto = false

		get_parent().label_interacao.visible = false
