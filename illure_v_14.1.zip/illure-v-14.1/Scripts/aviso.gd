extends Label

func _ready():
	GameManager.mostrar_ajuda.connect(mostrar_ajuda)

func mostrar_ajuda():

	text = "PRESSIONE O BOTÃO DE ATAQUE 'Q' DO IRMÃO!"
	visible = true
	modulate.a = 0

	# fade in
	for i in range(10):
		modulate.a += 0.1
		await get_tree().create_timer(0.05).timeout

	await get_tree().create_timer(2.0).timeout

	# fade out
	for i in range(10):
		modulate.a -= 0.1
		await get_tree().create_timer(0.05).timeout

	visible = false
