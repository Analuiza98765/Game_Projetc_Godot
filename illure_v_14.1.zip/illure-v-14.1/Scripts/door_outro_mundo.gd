extends Area2D

var player_perto = false

var ui
var label_interacao

func _ready():

	ui = get_tree().current_scene.get_node("CanvasLayer")
	label_interacao = ui.get_node("LabelInteracao")

	label_interacao.visible = false


func _process(_delta):

	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and GameManager.etapa == 6:

		GameManager.porta_outro_mundo = true
		GameManager.verificar_progresso()

		GameManager.portas_atravessadas += 1

		await get_tree().process_frame
		get_tree().change_scene_to_file("res://Scenes/outro_mundo.tscn")


func _on_body_entered(body):

	if body.is_in_group("player"):

		player_perto = true

		if GameManager.etapa == 6:
			label_interacao.text = "Pressione E para entrar"
			label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false
		label_interacao.visible = false
