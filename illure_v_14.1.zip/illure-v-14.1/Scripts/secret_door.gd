extends Area2D

var player_perto = false
var irmao_perto = false

var dialogo_mostrado = false

# UI GLOBAL
var ui
var label_interacao
var caixa_dialogo
var texto_dialogo

func _ready() -> void:
	visible = false

	ui = get_tree().current_scene.get_node("CanvasLayer")

	label_interacao = ui.get_node("LabelInteracao")
	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")

	label_interacao.visible = false
	caixa_dialogo.visible = false
	texto_dialogo.visible = false


func _process(_delta: float) -> void:
			
	if GameManager.etapa >= 12 and not visible:
		visible = true

	if (
		player_perto
		and irmao_perto
		and Input.is_action_just_pressed("interact")
	):
		GameManager.entrou_no_porao = true
		get_tree().change_scene_to_file("res://Scenes/porao.tscn")
		


func mostrar_dialogo(msg):

	GameManager.iniciar_dialogo()

	caixa_dialogo.visible = true
	texto_dialogo.visible = true

	texto_dialogo.text = msg

	await get_tree().create_timer(3.0).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	GameManager.encerrar_dialogo()


func _on_body_entered(body):

	if body.is_in_group("player"):

		player_perto = true

		if not dialogo_mostrado:

			dialogo_mostrado = true

			mostrar_dialogo("Lina: Essa porta não estava aqui...")

	if body.is_in_group("irmao"):

		irmao_perto = true


	if player_perto and irmao_perto:

		label_interacao.text = "Pressione E para entrar"
		label_interacao.visible = true


func _on_body_exited(body):

	if body.is_in_group("player"):
		player_perto = false

	if body.is_in_group("irmao"):
		irmao_perto = false

	label_interacao.visible = false
