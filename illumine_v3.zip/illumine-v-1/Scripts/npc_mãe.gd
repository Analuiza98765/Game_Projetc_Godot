extends Area2D

@onready var label_interação: Label = $LabelInteração
@onready var caixade_dialogo: Label = $CanvasLayer/CaixadeDialogo
@onready var texto_dialogo: Label = $CanvasLayer/TextoDialogo

var player_in_area = false
var falando = false
var pode_avancar = false
var fala_index = 0

var falas = [
	"Lina, já que você quer ajudar, pega aquela lista em cima da caixa",
	"Tem algumas coisas que eu não tô achando… vê se você consegue encontrar pra mim.",
	"Vai me ajudar muito se você resolver isso"
]

func _ready() -> void:
	caixade_dialogo.visible = false
	texto_dialogo.visible = false 
	label_interação.visible = false
	
func _process(_delta) -> void:
	if player_in_area and not falando and Input.is_action_just_pressed("interact"):
		iniciar_dialogo()
	elif falando and pode_avancar and Input.is_action_just_pressed("interact"):
		proxima_fala()
		 
	
func _on_body_entered(body: Node2D) -> void:
	if body.name == "Lina":
		player_in_area = true
		label_interação.text = "Pressione 'E' para interagir"
		label_interação.visible = true
		

func _on_body_exited(body: Node2D) -> void:
	if body.name == "Lina":
		player_in_area = false
		label_interação.visible = false
		if falando:
			encerrar_dialogo()
			
func iniciar_dialogo():
	falando = true
	label_interação.visible = false
	caixade_dialogo.visible = true
	texto_dialogo.visible = true
	fala_index = 0
	proxima_fala()
	
func proxima_fala():
	if fala_index < falas.size():
		pode_avancar = false
		texto_dialogo.text = ""
		var texto = falas[fala_index]
		fala_index += 1
		mostrar_texto_com_efeito(texto)
	else:
		encerrar_dialogo()
		
func mostrar_texto_com_efeito(texto: String):
	await get_tree().create_timer(0.1).timeout
	for letra in texto:
		texto_dialogo.text += letra
		await get_tree().create_timer(0.02).timeout
	pode_avancar = true

func encerrar_dialogo():
	falando =  false 
	pode_avancar = false
	texto_dialogo.visible = false
	caixade_dialogo.visible = false
	fala_index = 0

		
