extends Area2D

var velocity: Vector2 = Vector2.ZERO

func _ready():
	print("PEDRA CRIADA")

	await get_tree().create_timer(3.0).timeout
	queue_free()

func _process(delta):
	global_position += velocity * delta
