extends CharacterBody2D

@onready var player = get_tree().get_first_node_in_group("player")
@export var speed = 45
@export var velocidade_andar = 110
@export var destino_porta = Vector2(8, 1)
@export var destino_confronto = Vector2(52, 1)
@export var destino_arrombamento = Vector2(20, 4)


var direcao = Vector2.ZERO
var tempo = 0.0


func _ready():

	randomize()

	visible = false


func _physics_process(delta):

	# diálogo
	if GameManager.em_dialogo:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# parar NPC quando player aproxima
	if GameManager.npc_parado:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	# visibilidade
	if GameManager.etapa < 8:
		visible = false
		return

	if GameManager.etapa == 12:
		visible = false
		return

	visible = true

	# vai pra porta
	if GameManager.esperar_porta_mae:
		mover_para(destino_porta)
		return

	# confronto
	if GameManager.confronto_mae:
		mover_para(destino_confronto)
		return
	
	# perseguição
	if GameManager.pais_perseguem:
		perseguir_player()
		return
	
	# movimento normal
	tempo -= delta

	if tempo <= 0:
		nova_direcao()

	velocity = direcao * speed
	move_and_slide()


# =====================================
# MOVER PARA PONTO
# =====================================
func mover_para(destino):

	var direcao_destino = (
		destino - global_position
	)

	# chegou
	if direcao_destino.length() <= 5:

		velocity = Vector2.ZERO

		if GameManager.esperar_porta_mae:
			GameManager.mae_chegou_porta = true

		if GameManager.pais_arrombaram_porta:

			if has_node("../porta"):
				get_node("../porta").play("abrir")

	else:

		velocity = (
			direcao_destino.normalized()
			* velocidade_andar
		)

	move_and_slide()


func nova_direcao():

	var dirs = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2(1,1).normalized(),
		Vector2(-1,1).normalized(),
		Vector2(1,-1).normalized(),
		Vector2(-1,-1).normalized(),
		Vector2.ZERO
	]

	direcao = dirs[randi() % dirs.size()]

	tempo = randf_range(0.8, 2.0)
	
func perseguir_player():

	if player == null:
		return

	var direcao_player = (
		player.global_position - global_position
	).normalized()

	velocity = direcao_player * velocidade_andar

	move_and_slide()
