extends Area2D
@onready var sprite = $AnimatedSprite2D
@export var tipo_objeto = "quadro_sombrio"

var player_perto = false
var ja_interagiu = false

var ui
var caixa_dialogo
var texto_dialogo
var label_interacao


func _ready():
	sprite.play("idle")
	ui = get_tree().current_scene.get_node("CanvasLayer")

	caixa_dialogo = ui.get_node("CaixadeDialogo")
	texto_dialogo = ui.get_node("TextoDialogo")
	label_interacao = ui.get_node("LabelInteracao")


func _process(_delta):

	# só existe na etapa 11
	visible = GameManager.etapa >= 12

	if GameManager.etapa != 12:
		return

	if player_perto \
	and Input.is_action_just_pressed("interact") \
	and not GameManager.em_dialogo:
		print("apertou E")
		print(GameManager.em_dialogo)


		interagir()


func interagir():

	if ja_interagiu:
		return

	ja_interagiu = true

	GameManager.iniciar_dialogo()

	caixa_dialogo.visible = true
	texto_dialogo.visible = true
	label_interacao.visible = false

	match tipo_objeto:

		"boneca_quebrada":
			GameManager.pegar_objeto("boneca_quebrada")
			texto_dialogo.text = "Essa boneca não é nova... já foi de alguém antes de mim."
			

		"ursinho_rasgado":
			GameManager.pegar_objeto("ursinho_rasgado")
			texto_dialogo.text = "O ursinho está vazio por dentro... mas alguém já o abraçou por muito tempo."
			
		"bilhetes_socorro":
			GameManager.pegar_objeto("bilhetes_socorro")
			texto_dialogo.text = "Não é uma única voz pedindo ajuda... são várias."

		"sangue_chao":
			GameManager.pegar_objeto("sangue_chao")
			texto_dialogo.text = "O chão já viu isso antes... mais de uma vez."

		"objetos_tortura":
			GameManager.pegar_objeto("objetos_tortura")
			texto_dialogo.text = "Ferramentas gastas... como se fossem usadas muitas vezes."

		"mesa_jantar":
			GameManager.pegar_objeto("mesa_jantar")
			texto_dialogo.text = "A mesa nunca está realmente vazia... só esperando."
			
	await get_tree().create_timer(2.5).timeout

	caixa_dialogo.visible = false
	texto_dialogo.visible = false

	GameManager.encerrar_dialogo()

	GameManager.verificar_progresso()


func _on_body_entered(body):
	if body.is_in_group("player"):
		player_perto = true
		print("player entrou na área")

		label_interacao.visible = true
		label_interacao.text = "Pressione E para investigar"


func _on_body_exited(body):

	if body.is_in_group("player"):

		player_perto = false
		label_interacao.visible = false
